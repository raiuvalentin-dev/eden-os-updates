<?php
/* EDEN OS — chat public pentru vizitatori (potentiali clienti).
   Scrie mesajele in data/site_chat.json (canal "site"), pe care il citeste Inbox-ul platformei.
   Public (fara sesiune) — doar scriere de lead-uri; citirea completa e gardata. */
header('Content-Type: application/json; charset=utf-8');
$dir = __DIR__ . '/data';
if (!is_dir($dir)) @mkdir($dir, 0775, true);
$f = $dir . '/site_chat.json';
$method = $_SERVER['REQUEST_METHOD'];

function load($f){ if(!is_file($f)) return array(); $j=json_decode(file_get_contents($f),true); return is_array($j)?$j:array(); }

if ($method === 'POST') {
  $raw = file_get_contents('php://input');
  if (strlen($raw) > 20000) { http_response_code(413); echo json_encode(array('error'=>'too_large')); exit; }
  $in = json_decode($raw, true);
  if (!is_array($in) || !isset($in['mesaj']) || trim($in['mesaj']) === '') {
    http_response_code(400); echo json_encode(array('error'=>'bad_request')); exit;
  }
  $list = load($f);
  // rate-limit simplu pe IP: max 8 mesaje / 10 min
  $ipHash = hash('sha256', (isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'') . 'uh-salt');
  $now = time(); $recent = 0;
  foreach ($list as $m) { if (isset($m['ip']) && $m['ip']===$ipHash && ($now - (int)$m['ts']) < 600) $recent++; }
  if ($recent >= 8) { http_response_code(429); echo json_encode(array('error'=>'rate_limited')); exit; }

  $entry = array(
    'id'      => uniqid('lead_'),
    'nume'    => mb_substr(trim(isset($in['nume'])?$in['nume']:''), 0, 120),
    'contact' => mb_substr(trim(isset($in['contact'])?$in['contact']:''), 0, 160),
    'mesaj'   => mb_substr(trim($in['mesaj']), 0, 4000),
    'canal'   => 'site',
    'stare'   => 'nou',
    'ts'      => $now,
    'ip'      => $ipHash
  );
  $list[] = $entry;
  if (count($list) > 1000) $list = array_slice($list, -1000);
  file_put_contents($f, json_encode($list, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
  echo json_encode(array('ok'=>true, 'id'=>$entry['id']));
  exit;
}

if ($method === 'GET') {
  // public: doar numarul de mesaje (fara continut). Citirea completa se face din Inbox (gardat).
  $list = load($f);
  echo json_encode(array('ok'=>true, 'count'=>count($list)));
  exit;
}

http_response_code(405);
echo json_encode(array('error'=>'method_not_allowed'));
