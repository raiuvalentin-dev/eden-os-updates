<?php
// EDEN OS — Autorizari eveniment: evenimente pe companii, arhiva de documente pe eveniment + preluare din e-mail (beta).
// Acces DOAR cu sesiune valida (login prin auth.php). Contul owner vede tot; ceilalti utilizatori vad numai companiile la care au primit drept.
// Evenimentele si fisierele stau in data/autorizari/ (director inchis accesului web).
// Compatibil PHP 7.4. Fara parole sau chei in cod: parola casutei de e-mail o introduce owner-ul din aplicatie si ramane in data/.

@set_time_limit(120);
@ini_set('display_errors', '0');
@date_default_timezone_set('Europe/Bucharest');
$AZ_DIR  = __DIR__ . '/data';
$AZ_ROOT = $AZ_DIR . '/autorizari';
$AZ_MAX  = 80 * 1024 * 1024;      // marime maxima pe fisier
$AZ_CHUNK = 4 * 1024 * 1024;      // marime maxima pe bucata incarcata

function az_mkdirs() {
  global $AZ_DIR, $AZ_ROOT;
  foreach (array($AZ_DIR, $AZ_ROOT, $AZ_ROOT . '/f', $AZ_ROOT . '/tmp', $AZ_ROOT . '/sterse', $AZ_ROOT . '/ev') as $d) { if (!is_dir($d)) { @mkdir($d, 0755, true); } }
  foreach (array($AZ_ROOT . '/.htaccess', $AZ_ROOT . '/f/.htaccess') as $h2) { if (!is_file($h2)) { @file_put_contents($h2, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n"); } }
  if (mt_rand(0, 19) === 0) { foreach ((array)@glob($AZ_ROOT . '/tmp/*') as $t) { if (is_file($t) && filemtime($t) < time() - 86400) @unlink($t); } }   // incarcari abandonate
  $ht = $AZ_DIR . '/.htaccess';
  if (!is_file($ht)) { @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n"); }
}
function az_jload($f) { if (!is_file($f)) return array(); $d = json_decode(@file_get_contents($f), true); return is_array($d) ? $d : array(); }
function az_jsave($f, $d, $mode = 0) {      // scriere atomica; daca nu se poate serializa sau scrie complet, fisierul vechi ramane neatins
  $j = json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
  if ($j === false || $j === '' || $j === 'null') return false;
  $t = $f . '.tmp'; if ($mode) { @touch($t); @chmod($t, $mode); }
  if (@file_put_contents($t, $j, LOCK_EX) !== strlen($j)) { @unlink($t); return false; }
  return @rename($t, $f);
}
function az_out($d) { header('Content-Type: application/json; charset=utf-8'); header('X-Content-Type-Options: nosniff'); header('Cache-Control: no-store'); echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function az_fail($code, $msg, $extra = array()) { http_response_code($code); az_out(array_merge(array('ok' => false, 'error' => $msg), $extra)); }
function az_session() {
  global $AZ_DIR;
  $tok = isset($_SERVER['HTTP_X_EDEN_SESSION']) ? $_SERVER['HTTP_X_EDEN_SESSION'] : '';
  if (!$tok || !preg_match('/^[A-Za-z0-9_-]{8,128}$/', $tok)) return null;
  $s = az_jload($AZ_DIR . '/sessions.json');
  if (!isset($s[$tok]) || !isset($s[$tok]['exp']) || $s[$tok]['exp'] < time()) return null;
  return $s[$tok];
}
function az_id() { return bin2hex(random_bytes(12)); }
function az_okid($id) { return is_string($id) && preg_match('/^[a-f0-9]{16,40}\z/D', $id); }
function az_okev($ev) { return is_string($ev) && preg_match('/^[A-Za-z0-9_-]{1,64}\z/D', $ev); }
function az_name($n) {
  $n = str_replace(array("\0", "\r", "\n", "\t"), ' ', (string)$n);
  $n = preg_replace('#^.*[\\\\/]#', '', $n);
  $n = trim(preg_replace('/\s+/', ' ', $n));
  if (function_exists('mb_substr')) { $n = mb_substr($n, 0, 180, 'UTF-8'); } else { $n = substr($n, 0, 180); }
  return $n === '' ? 'document' : $n;
}
function az_lower($s) { return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s); }
function az_utf8($s, $cs = '') {
  $cs = strtoupper(trim($cs));
  if ($cs !== '' && $cs !== 'UTF-8' && $cs !== 'UTF8' && $cs !== 'US-ASCII') {
    if (!preg_match('/^[A-Z0-9._:-]{2,40}\z/D', $cs)) $cs = 'ISO-8859-2';
    try { if (function_exists('mb_convert_encoding')) { $r = @mb_convert_encoding($s, 'UTF-8', $cs); if ($r !== false && $r !== '') return $r; } } catch (\Throwable $e) {}
    try { if (function_exists('iconv')) { $r = @iconv($cs, 'UTF-8//IGNORE', $s); if ($r !== false) return $r; } } catch (\Throwable $e) {}
  }
  if (function_exists('mb_check_encoding') && !mb_check_encoding($s, 'UTF-8')) { $r = @mb_convert_encoding($s, 'UTF-8', 'ISO-8859-2'); return $r === false ? '' : $r; }
  return $s;
}

/* ---------- index ---------- */
function az_index_path() { global $AZ_ROOT; return $AZ_ROOT . '/index.json'; }
function az_index_edit($fn) {            // modificare atomica, cu blocare
  global $AZ_ROOT;
  $lk = fopen($AZ_ROOT . '/index.lock', 'c'); if ($lk) flock($lk, LOCK_EX);
  $p = az_index_path(); clearstatcache();
  if (is_file($p) && filesize($p) > 0) { $ix = json_decode(@file_get_contents($p), true); if (!is_array($ix) || !isset($ix['files']) || !is_array($ix['files'])) { if ($lk) { flock($lk, LOCK_UN); fclose($lk); } return null; } }   // index ilizibil: nu-l suprascriem
  else $ix = array('v' => 1, 'files' => array());
  $r = $fn($ix);
  if ($r !== null && $r !== false && !az_jsave($p, $ix)) $r = null;
  if ($lk) { flock($lk, LOCK_UN); fclose($lk); }
  return $r;
}
function az_index() { $ix = az_jload(az_index_path()); return isset($ix['files']) && is_array($ix['files']) ? $ix['files'] : array(); }

/* ---------- clasificare: institutie si fel, dupa nume / subiect / expeditor ---------- */
function az_clasifica($name, $subj = '', $from = '') {
  $n = az_lower($name); $t = az_lower($name . ' ' . $subj); $f = az_lower($from);
  $cod = ''; $inst = ''; $tip = 'document';
  if (preg_match('/^\s*(?:\d{1,2}[_ -]+)?((ISU|DSV|DSP|ANPC|MED|POL|GEN|CER|PV|EL|DT|LX|PG|PM|DOC)[-_ ]?P?\d{1,2}[a-z]?)(?![0-9])/i', $name, $m)) { $cod = strtoupper(str_replace(array('_', ' '), '-', $m[1])); }
  elseif (preg_match('/(?<![A-Za-z])((ISU|DSV|DSP|MED|DT|LX|PG|PM|EL)-P?\d{1,2}[a-z]?)(?![0-9A-Za-z])/i', $name, $m)) { $cod = strtoupper($m[1]); }
  $pre = $cod !== '' ? preg_replace('/[^A-Z].*$/', '', $cod) : '';
  $map = array('ISU' => 'ISU', 'DSV' => 'DSV', 'DSP' => 'DSP', 'ANPC' => 'ANPC', 'MED' => 'MEDIU', 'POL' => 'POLITIE', 'GEN' => 'GEN', 'EL' => 'ISU', 'DT' => 'ISU', 'LX' => 'ISU', 'PG' => 'POLITIE', 'CER' => 'ISU', 'PV' => 'ISU');
  if ($pre !== '' && isset($map[$pre])) $inst = $map[$pre];
  if ($inst === '') {
    if (preg_match('/isu|igsu|incendiu|pompier|psi\b|evacuare|stingator/u', $t . ' ' . $f)) $inst = 'ISU';
    elseif (preg_match('/dsvsa|ansvsa|sanitar[ -]?veterinar|\bdsv\b/u', $t . ' ' . $f)) $inst = 'DSV';
    elseif (preg_match('/\bdsp\b|dspb|sanatate publica|sănătate publică|igienico/u', $t . ' ' . $f)) $inst = 'DSP';
    elseif (preg_match('/anpc|protectia consumator|protecția consumator/u', $t . ' ' . $f)) $inst = 'ANPC';
    elseif (preg_match('/anpm|apmb|\bapm\b|gnm|garda de mediu|garda nationala de mediu|mediu|deseuri|deșeuri|\bsgr\b/u', $t . ' ' . $f)) $inst = 'MEDIU';
    elseif (preg_match('/politi|poliți|jandarm|ordine publica|ordine publică|paza|pază|brigada rutiera/u', $t . ' ' . $f)) $inst = 'POLITIE';
    else $inst = 'GEN';
  }
  if (preg_match('/factur|invoice|proforma|\bfact[._ -]|e-?factura|chitan|bon fiscal|\bop[ _-]?\d|ordin de plat/u', $t)) $tip = 'factura';
  elseif (preg_match('/contract|act adi[tț]ional|acord de|comand[aă] ferm|conven[tț]ie/u', $t)) $tip = 'contract';
  elseif ($pre === 'PV' || preg_match('/proces[- _]?verbal|^pv[ _-]/u', $n)) $tip = 'pv';
  elseif ($pre === 'CER' || preg_match('/certificat|agrement|declara[tț]ie de (conformitate|performan)|buletin|atestat|autoriza[tț]i[ea] |licen[tț]/u', $t)) $tip = 'certificat';
  elseif (preg_match('/-p\d|plan[sș][aăe]|^(\d{1,2}[_ -])?plan[_ -]|\bplan de (situa|evacu|amplas|amenaj|mese)|layout|\.dwg$|\.dxf$/u', $n) || in_array($pre, array('DT', 'LX', 'PG', 'PM'))) $tip = 'plansa';
  return array('inst' => $inst, 'tip' => $tip, 'cod' => $cod);
}

/* ---------- e-Factura (UBL XML): furnizor, numar, date, sume ---------- */
function az_efactura($path) {
  if (!function_exists('simplexml_load_string')) return null;
  $raw = @file_get_contents($path, false, null, 0, 3000000); if ($raw === false || stripos($raw, 'Invoice') === false) return null;
  if (preg_match('/<!\s*(DOCTYPE|ENTITY)/i', $raw)) return null;        // fara DTD / entitati
  $prev = libxml_use_internal_errors(true);
  $x = @simplexml_load_string($raw, 'SimpleXMLElement', LIBXML_NONET);
  libxml_clear_errors(); libxml_use_internal_errors($prev);
  if ($x === false || $x === null) return null;
  $x->registerXPathNamespace('cbc', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
  $x->registerXPathNamespace('cac', 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
  $g = function ($q) use ($x) { $r = @$x->xpath($q); return ($r && isset($r[0])) ? trim((string)$r[0]) : ''; };
  $total = $g('//cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount'); if ($total === '') $total = $g('//cac:LegalMonetaryTotal/cbc:PayableAmount');
  if ($total === '') return null;
  $cur = ''; $r = @$x->xpath('//cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount/@currencyID'); if ($r && isset($r[0])) $cur = (string)$r[0];
  $furn = $g('//cac:AccountingSupplierParty//cac:PartyLegalEntity/cbc:RegistrationName'); if ($furn === '') $furn = $g('//cac:AccountingSupplierParty//cac:PartyName/cbc:Name');
  return array('furnizor' => $furn, 'cui' => $g('//cac:AccountingSupplierParty//cac:PartyTaxScheme/cbc:CompanyID'), 'nr' => $g('/*/cbc:ID'), 'data' => $g('/*/cbc:IssueDate'), 'scadenta' => $g('/*/cbc:DueDate'),
    'baza' => $g('//cac:LegalMonetaryTotal/cbc:TaxExclusiveAmount'), 'tva' => $g('/*/cac:TaxTotal/cbc:TaxAmount'), 'total' => $total, 'moneda' => $cur !== '' ? $cur : 'RON', 'auto' => 'e-Factura');
}

/* ---------- adaugare fisier in arhiva (folosita la incarcare si la e-mail) ---------- */
function az_add_file($tmpPath, $meta, $by) {
  global $AZ_ROOT;
  $id = isset($meta['id']) && az_okid($meta['id']) ? $meta['id'] : az_id();
  $dst = $AZ_ROOT . '/f/' . $id;
  if ($tmpPath !== null) { if (!@rename($tmpPath, $dst)) { if (!@copy($tmpPath, $dst)) return null; @unlink($tmpPath); } }
  $name = az_name(isset($meta['name']) ? $meta['name'] : 'document');
  $cl = az_clasifica($name, isset($meta['subj']) ? $meta['subj'] : '', isset($meta['from']) ? $meta['from'] : '');
  $rec = array('id' => $id, 'ev' => isset($meta['ev']) && az_okev($meta['ev']) ? $meta['ev'] : '_inbox', 'name' => $name,
    'size' => $tmpPath !== null ? (int)@filesize($dst) : 0, 'ts' => time(), 'by' => $by,
    'inst' => !empty($meta['inst']) ? substr(preg_replace('/[^A-Z]/', '', strtoupper($meta['inst'])), 0, 10) : $cl['inst'],
    'tip' => !empty($meta['tip']) ? substr(preg_replace('/[^a-z]/', '', strtolower($meta['tip'])), 0, 16) : $cl['tip'],
    'cod' => isset($meta['cod']) && $meta['cod'] !== '' ? substr(az_name($meta['cod']), 0, 24) : $cl['cod'],
    'src' => isset($meta['src']) ? substr(preg_replace('/[^a-z]/', '', $meta['src']), 0, 10) : 'upload');
  foreach (array('from', 'subj', 'mdate', 'nota', 'grup') as $k) { if (isset($meta[$k]) && $meta[$k] !== '') $rec[$k] = function_exists('mb_substr') ? mb_substr((string)$meta[$k], 0, 300, 'UTF-8') : substr((string)$meta[$k], 0, 300); }
  if ($tmpPath === null) $rec['nofile'] = true;
  if (isset($meta['fin']) && is_array($meta['fin'])) { $fc = az_fin_clean($meta['fin']); if ($fc) $rec['fin'] = $fc; }
  if ($tmpPath !== null && preg_match('/\.xml$/i', $name)) { $ef = az_efactura($dst); if ($ef) { $rec['tip'] = 'factura'; $rec['fin'] = az_fin_clean(array_merge($ef, isset($rec['fin']) ? $rec['fin'] : array())); } }
  $ok = az_index_edit(function (&$ix) use ($rec) { $ix['files'][$rec['id']] = $rec; return true; });
  if (!$ok) { if ($tmpPath !== null) @unlink($dst); return null; }
  return $rec;
}
function az_fin_clean($f) {
  $o = array();
  foreach (array('furnizor', 'cui', 'nr', 'data', 'scadenta', 'categorie', 'moneda', 'obiect', 'data_plata', 'auto') as $k) { if (isset($f[$k]) && is_scalar($f[$k]) && $f[$k] !== '') $o[$k] = function_exists('mb_substr') ? mb_substr(trim((string)$f[$k]), 0, 160, 'UTF-8') : substr(trim((string)$f[$k]), 0, 160); }
  foreach (array('baza', 'tva', 'total') as $k) { if (isset($f[$k]) && $f[$k] !== '' && is_numeric($f[$k]) && is_finite((float)$f[$k]) && abs((float)$f[$k]) < 1e12) $o[$k] = round((float)$f[$k], 2); }
  if (!empty($f['platit'])) $o['platit'] = true;
  return $o;
}


/* ---------- companii, drepturi pe companie, evenimente pastrate pe server ---------- */
function az_txt($v, $max = 200) {
  if (!is_scalar($v)) return '';
  $s = @preg_replace('/[\x00-\x1F\x7F]+/u', ' ', (string)$v); if ($s === null) $s = preg_replace('/[\x00-\x1F\x7F]+/', ' ', az_utf8((string)$v));
  $s = trim($s);
  return function_exists('mb_substr') ? mb_substr($s, 0, $max, 'UTF-8') : substr($s, 0, $max);
}
function az_owner($me) { return isset($me['role']) && $me['role'] === 'owner'; }
function az_co_path() { global $AZ_ROOT; return $AZ_ROOT . '/companii.json'; }
function az_co() {
  $c = az_jload(az_co_path());
  if (!isset($c['list']) || !is_array($c['list'])) $c['list'] = array();
  if (!isset($c['acces']) || !is_array($c['acces'])) $c['acces'] = array();
  return $c;
}
function az_co_edit($fn) {            // modificare atomica, cu blocare
  global $AZ_ROOT;
  $lk = fopen($AZ_ROOT . '/companii.lock', 'c'); if ($lk) flock($lk, LOCK_EX);
  $p = az_co_path(); clearstatcache(); $r = null;
  $bun = true; if (is_file($p) && filesize($p) > 0) { $t = json_decode(@file_get_contents($p), true); if (!is_array($t)) $bun = false; }   // fisier ilizibil: nu-l suprascriem
  if ($bun) { $c = az_co(); $r = $fn($c); if ($r !== null && $r !== false && !az_jsave($p, $c)) $r = null; }
  if ($lk) { flock($lk, LOCK_UN); fclose($lk); }
  return $r;
}
function az_okco($id) { return is_string($id) && preg_match('/^c[a-f0-9]{8,24}\z/D', $id); }
function az_co_key($n) {
  $n = (string)$n;
  $n = preg_replace('/^\s*s\.?\s*c\.?\s+/iu', '', $n); $n = preg_replace('/[\s,]*s\.?\s*r\.?\s*l\.?\s*$/iu', '', (string)$n);
  $n = az_lower((string)$n);
  if (function_exists('iconv')) { $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $n); if ($t !== false && $t !== '') $n = $t; }
  return preg_replace('/[^a-z0-9]+/', '', strtolower($n));
}
function az_co_find_or_add(&$C, $den, $org, $by) {
  $den = az_txt($den, 160);
  if ($den === '' || $den[0] === '[' || stripos($den, 'de completat') !== false) { $den = 'Universul Horeca SRL'; $org = array(); }
  $k = az_co_key($den); $cui = isset($org['cui']) ? preg_replace('/\D+/', '', (string)$org['cui']) : '';
  foreach ($C['list'] as $id => $c) {
    if (az_co_key(isset($c['nume']) ? $c['nume'] : '') === $k) return $id;
    if ($cui !== '' && isset($c['cui']) && preg_replace('/\D+/', '', (string)$c['cui']) === $cui) return $id;
  }
  $id = 'c' . bin2hex(random_bytes(6));
  $rec = array('id' => $id, 'nume' => $den, 'creat' => time(), 'de' => $by);
  foreach (array('cui', 'j', 'sediu', 'rep', 'functie', 'tel', 'email') as $f) { if (isset($org[$f]) && az_txt($org[$f], 300) !== '') $rec[$f] = az_txt($org[$f], 300); }
  $C['list'][$id] = $rec;
  return $id;
}
/* drept pe companie: 0 = fara acces, 1 = vede, 2 = modifica, 3 = administreaza (sterge evenimente, muta intre companii). Contul owner are 3 peste tot. */
function az_drept($me, $co, $C) {
  if (az_owner($me)) return 3;
  $u = isset($me['user']) ? (string)$me['user'] : '';
  $d = ($u !== '' && isset($C['acces'][$u]) && is_array($C['acces'][$u]) && isset($C['acces'][$u][$co])) ? $C['acces'][$u][$co] : '';
  return $d === 'admin' ? 3 : ($d === 'edit' ? 2 : ($d === 'view' ? 1 : 0));
}
function az_drept_max($me, $C) { if (az_owner($me)) return 3; $m = 0; foreach ($C['list'] as $id => $c) { $m = max($m, az_drept($me, (string)$id, $C)); } return $m; }
function az_okevid($id) { return az_okev($id) && $id[0] !== '_' && $id[0] !== '-'; }
function az_ev_path($id) { global $AZ_ROOT; return $AZ_ROOT . '/ev/' . $id . '.json'; }
function az_ev_get($id) { if (!az_okevid($id)) return null; $r = az_jload(az_ev_path($id)); return (isset($r['id'], $r['co'], $r['data']) && is_string($r['data'])) ? $r : null; }
function az_ev_all() {
  global $AZ_ROOT; $o = array();
  foreach ((array)@glob($AZ_ROOT . '/ev/*.json') as $f) { $r = az_jload($f); if (isset($r['id'], $r['co'], $r['data']) && is_string($r['data'])) $o[] = $r; }
  return $o;
}
function az_ev_edit($id, $fn) {       // modificare atomica a unui eveniment; $fn primeste inregistrarea curenta (sau null) si intoarce inregistrarea noua ori array('__err' => array(cod, mesaj))
  global $AZ_ROOT;
  $lk = fopen($AZ_ROOT . '/ev.lock', 'c'); if ($lk) flock($lk, LOCK_EX);
  clearstatcache(); $p = az_ev_path($id); $cur = az_ev_get($id);
  if (!$cur && is_file($p) && filesize($p) > 0) $new = array('__err' => array(500, 'fisierul evenimentului nu poate fi citit; nu l-am suprascris'));
  else { $new = $fn($cur); if (is_array($new) && !isset($new['__err']) && !az_jsave($p, $new)) $new = array('__err' => array(500, 'nu am putut salva evenimentul')); }
  if ($lk) { flock($lk, LOCK_UN); fclose($lk); }
  return $new;
}
function az_ev_drept($me, $ev, $C) {  // dreptul asupra unui eveniment (si asupra fisierelor lui)
  if ($ev === '_inbox') return az_owner($me) ? 3 : 0;      // mesajele neatribuite pot tine de orice companie: numai owner
  $e = az_ev_get($ev);
  if (!$e) return az_owner($me) ? 3 : 0;
  $d = az_drept($me, $e['co'], $C);
  if (!empty($e['del'])) return $d >= 3 ? 1 : 0;        // eveniment sters: doar citire, pentru cine administreaza compania
  return $d;
}
function az_ev_pub($e) { return array('id' => $e['id'], 'co' => $e['co'], 'rev' => (int)$e['rev'], 'ts' => (int)$e['ts'], 'by' => isset($e['by']) ? $e['by'] : '', 'data' => $e['data']); }
function az_migrate() {               // o singura data: evenimentele din starea comuna EDEN trec in data/autorizari/ev/, fiecare la compania organizatorului
  global $AZ_DIR, $AZ_ROOT;
  $flag = $AZ_ROOT . '/ev/.migrat'; if (is_file($flag)) return;
  $lk = fopen($AZ_ROOT . '/ev.lock', 'c'); if ($lk) flock($lk, LOCK_EX);
  clearstatcache();
  if (!is_file($flag)) {
    $n = 0; $raw = is_file($AZ_DIR . '/state.json') ? @file_get_contents($AZ_DIR . '/state.json') : '';
    $st = $raw !== '' && $raw !== false ? json_decode($raw) : null;       // fara „assoc”: obiectele goale raman obiecte
    $evs = (is_object($st) && isset($st->state->autorizari->events) && is_object($st->state->autorizari->events)) ? $st->state->autorizari->events : null;
    $bun = ($raw === '' || $raw === false) ? !is_file($AZ_DIR . '/state.json') : is_object($st);       // stare ilizibila: nu marcam migrarea ca facuta
    if ($evs) {
      @file_put_contents($AZ_ROOT . '/migrare_stare_' . date('Ymd_His') . '.json', json_encode($st->state->autorizari, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));   // copie de siguranta
      $okm = az_co_edit(function (&$C) use ($evs, &$n) {
        foreach ($evs as $id => $e) {
          $id = (string)$id; if (!az_okevid($id) || !is_object($e) || is_file(az_ev_path($id))) continue;
          $org = (isset($e->org) && is_object($e->org)) ? json_decode(json_encode($e->org), true) : array();
          $co = az_co_find_or_add($C, isset($org['den']) ? $org['den'] : '', is_array($org) ? $org : array(), 'migrare');
          $e->id = $id; $data = json_encode($e, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); if ($data === false) continue;
          if (az_jsave(az_ev_path($id), array('id' => $id, 'co' => $co, 'rev' => 1, 'ts' => time(), 'by' => 'migrare', 'creat' => time(), 'data' => $data))) $n++;
        }
        return true;
      });
      if (!$okm) $bun = false;
      if ($bun) {        // evenimentele complete nu mai raman in starea comuna, pe care o poate citi orice cont
        unset($st->state->autorizari->events, $st->state->autorizari->cur);
        $j = json_encode($st, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($j !== false && $j !== '') { $t = $AZ_DIR . '/state.json.tmp'; if (@file_put_contents($t, $j, LOCK_EX) === strlen($j)) @rename($t, $AZ_DIR . '/state.json'); else @unlink($t); }
      }
    }
    if ($bun) @file_put_contents($flag, date('c') . ' ' . $n . "\n");
  }
  if ($lk) { flock($lk, LOCK_UN); fclose($lk); }
}

/* ---------- evenimentele cunoscute, pentru repartizarea e-mailurilor ---------- */
function az_events() {
  $out = array();
  foreach (az_ev_all() as $e) {
    if (!empty($e['del'])) continue; $d = json_decode($e['data'], true); if (!is_array($d)) continue;
    $out[] = array('id' => (string)$e['id'], 'nume' => isset($d['nume']) && is_scalar($d['nume']) ? (string)$d['nume'] : '', 'cod' => isset($d['cod_mail']) && is_scalar($d['cod_mail']) ? strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$d['cod_mail'])) : '', 'faza' => isset($d['faza']) && is_scalar($d['faza']) ? (string)$d['faza'] : '');
  }
  return $out;
}
function az_route($to, $subj) {
  $evs = az_events(); $hay = strtoupper($to . ' ' . $subj); $hit = array();
  foreach ($evs as $e) { if ($e['cod'] !== '' && strlen($e['cod']) >= 4 && (strpos($hay, '[' . $e['cod'] . ']') !== false || strpos($hay, '+' . $e['cod'] . '@') !== false)) $hit[$e['id']] = $e['cod'];
  }
  if (count($hit) === 1 && count(array_keys(array_column($evs, 'cod'), reset($hit))) === 1) return array(key($hit), 'cod');      // cod explicit si unic
  return array('_inbox', 'neatribuit');
}

/* ---------- MIME ---------- */
function az_hdr_decode($s) {
  $s = preg_replace('/(\?=)\s+(=\?)/', '$1$2', $s);
  return az_utf8(preg_replace_callback('/=\?([^?]+)\?([BbQq])\?([^?]*)\?=/', function ($m) {
    $d = strtoupper($m[2]) === 'B' ? base64_decode($m[3]) : quoted_printable_decode(str_replace('_', ' ', $m[3]));
    return az_utf8($d, $m[1]);
  }, $s));
}
function az_hdrs($block) {
  $h = array(); $block = preg_replace('/\r?\n[ \t]+/', ' ', $block);
  foreach (preg_split('/\r?\n/', $block) as $ln) { $p = strpos($ln, ':'); if ($p === false) continue; $k = strtolower(trim(substr($ln, 0, $p))); $v = trim(substr($ln, $p + 1, 4000)); if (!isset($h[$k])) $h[$k] = $v; }
  return $h;
}
function az_params($v) {              // "text/plain; charset=utf-8; name*=UTF-8''x.pdf" -> [valoare, parametri]
  $parts = preg_split('/;(?=(?:[^"]*"[^"]*")*[^"]*$)/', $v); $main = strtolower(trim(array_shift($parts))); $p = array(); $ext = array();
  foreach ($parts as $x) { $e = strpos($x, '='); if ($e === false) continue; $k = strtolower(trim(substr($x, 0, $e))); $val = trim(substr($x, $e + 1)); if (strlen($val) > 1 && $val[0] === '"' && substr($val, -1) === '"') $val = stripcslashes(substr($val, 1, -1));
    if (preg_match('/^([^*]+)\*(\d*)(\*?)$/', $k, $m)) { $base = $m[1]; $i = $m[2] === '' ? 0 : (int)$m[2]; $ext[$base][$i] = array($val, $m[2] === '' || $m[3] === '*'); }
    else $p[$k] = $val; }
  foreach ($ext as $base => $segs) { ksort($segs); $cs = ''; $out = ''; foreach ($segs as $i => $s) { $val = $s[0]; if ($s[1]) { if ($i === 0 && preg_match("/^([^']*)'[^']*'(.*)$/", $val, $mm)) { $cs = $mm[1]; $val = $mm[2]; } $val = rawurldecode($val); } $out .= $val; } $p[$base] = az_utf8($out, $cs); }
  return array($main, $p);
}
function az_mime_leaves($raw, $depth = 0, &$out = null) {
  if ($out === null) $out = array();
  $pos = strpos($raw, "\r\n\r\n"); $sep = 4; if ($pos === false) { $pos = strpos($raw, "\n\n"); $sep = 2; }
  if ($pos === false) { $head = $raw; $body = ''; } else { $head = substr($raw, 0, $pos); $body = substr($raw, $pos + $sep); }
  $h = az_hdrs($head);
  list($ct, $cp) = az_params(isset($h['content-type']) ? $h['content-type'] : 'text/plain');
  if (strpos($ct, 'multipart/') === 0 && isset($cp['boundary']) && $depth < 8) {
    $segs = explode('--' . $cp['boundary'], $body); array_shift($segs);
    foreach ($segs as $sg) { if (substr($sg, 0, 2) === '--') break; $sg = preg_replace('/^[ \t]*\r?\n/', '', $sg); $sg = preg_replace('/\r?\n$/', '', $sg); az_mime_leaves($sg, $depth + 1, $out); }
    return $out;
  }
  if ($ct === 'message/rfc822' && $depth < 8) { az_mime_leaves($body, $depth + 1, $out); return $out; }
  $enc = strtolower(isset($h['content-transfer-encoding']) ? trim($h['content-transfer-encoding']) : '');
  if ($enc === 'base64') $data = base64_decode(preg_replace('/\s+/', '', $body)); elseif ($enc === 'quoted-printable') $data = quoted_printable_decode($body); else $data = $body;
  list($disp, $dp) = az_params(isset($h['content-disposition']) ? $h['content-disposition'] : '');
  $fn = isset($dp['filename']) ? $dp['filename'] : (isset($cp['name']) ? $cp['name'] : ''); if ($fn !== '') $fn = az_hdr_decode($fn);
  $out[] = array('ct' => $ct, 'charset' => isset($cp['charset']) ? $cp['charset'] : '', 'disp' => $disp, 'name' => $fn, 'data' => $data === false ? '' : $data);
  return $out;
}
function az_msg_parse($raw) {
  $pos = strpos($raw, "\r\n\r\n"); if ($pos === false) $pos = strpos($raw, "\n\n"); $h = az_hdrs($pos === false ? $raw : substr($raw, 0, $pos));
  $leaves = az_mime_leaves($raw); $text = ''; $html = ''; $att = array();
  foreach ($leaves as $l) {
    $isAtt = $l['name'] !== '' || $l['disp'] === 'attachment';
    if (!$isAtt && $l['ct'] === 'text/plain') { if ($text === '') $text = az_utf8($l['data'], $l['charset']); continue; }
    if (!$isAtt && $l['ct'] === 'text/html') { if ($html === '') $html = az_utf8($l['data'], $l['charset']); continue; }
    if ($l['data'] === '') continue;
    if (preg_match('/\.(p7s|p7m|asc|vcf|ics)$/i', $l['name']) || $l['ct'] === 'application/pkcs7-signature') continue;
    if (strpos($l['ct'], 'image/') === 0 && $l['disp'] !== 'attachment' && strlen($l['data']) < 25000) continue;   // sigle din semnatura
    if ($l['name'] === '') { $ext = array('application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png', 'text/xml' => 'xml', 'application/xml' => 'xml'); if (!isset($ext[$l['ct']])) continue; $l['name'] = 'atasament.' . $ext[$l['ct']]; }
    if (count($att) < 30) $att[] = array('name' => az_name($l['name']), 'data' => $l['data']);
  }
  if (strlen($html) > 300000) $html = substr($html, 0, 300000);
  if (strlen($text) > 300000) $text = substr($text, 0, 300000);
  if ($text === '' && $html !== '') { $text = html_entity_decode(trim(preg_replace('/[ \t]+/', ' ', preg_replace('/\n\s*\n\s*\n+/', "\n\n", strip_tags(preg_replace(array('#<(br|/p|/div|/tr|/h\d)[^>]*>#i', '#<(style|script)[^>]*>.*?</\1>#is'), array("\n", ''), $html))))), ENT_QUOTES, 'UTF-8'); }
  return array('from' => az_hdr_decode(isset($h['from']) ? $h['from'] : ''), 'to' => az_hdr_decode((isset($h['to']) ? $h['to'] : '') . ' ' . (isset($h['delivered-to']) ? $h['delivered-to'] : '') . ' ' . (isset($h['x-original-to']) ? $h['x-original-to'] : '') . ' ' . (isset($h['cc']) ? $h['cc'] : '')),
    'subj' => az_hdr_decode(isset($h['subject']) ? $h['subject'] : ''), 'date' => isset($h['date']) ? $h['date'] : '', 'mid' => isset($h['message-id']) ? trim($h['message-id']) : '', 'text' => $text, 'att' => $att);
}

/* ---------- IMAP minim, pe socket (fara extensia php-imap) ---------- */
function az_imap_read($fp, $tag) {
  $lines = array(); $lits = array();
  while (true) {
    $ln = fgets($fp); if ($ln === false) return array(false, $lines, $lits, 'conexiune intrerupta');
    while (preg_match('/\{(\d+)\}\r?\n$/', $ln, $m)) {
      $n = (int)$m[1]; $buf = '';
      while (strlen($buf) < $n) { $c = fread($fp, min(65536, $n - strlen($buf))); if ($c === false || $c === '') return array(false, $lines, $lits, 'conexiune intrerupta'); $buf .= $c; }
      $lits[] = $buf; $lines[] = $ln; $ln = fgets($fp); if ($ln === false) return array(false, $lines, $lits, 'conexiune intrerupta');
    }
    if (strpos($ln, $tag . ' ') === 0) { return array(stripos($ln, $tag . ' OK') === 0, $lines, $lits, trim(substr($ln, strlen($tag) + 1))); }
    $lines[] = $ln;
  }
}
function az_imap_cmd($fp, &$n, $cmd) { $n++; $tag = 'A' . $n; fwrite($fp, $tag . ' ' . $cmd . "\r\n"); return az_imap_read($fp, $tag); }
function az_imap_q($s) { return '"' . str_replace(array('\\', '"'), array('\\\\', '\\"'), str_replace(array("\r", "\n", "\0"), '', $s)) . '"'; }
function az_imap_open($cfg, &$err) {
  $host = isset($cfg['host']) ? $cfg['host'] : ''; $port = isset($cfg['port']) ? (int)$cfg['port'] : 993;
  if ($host === '' || empty($cfg['user']) || !isset($cfg['pass']) || $cfg['pass'] === '') { $err = 'casuta nu este configurata'; return null; }
  $local = in_array(strtolower($host), array('localhost', '127.0.0.1', '::1'));
  $noverify = $local || !empty($cfg['noverify']);
  $ctx = stream_context_create(array('ssl' => array('verify_peer' => !$noverify, 'verify_peer_name' => !$noverify, 'allow_self_signed' => $noverify)));
  $scheme = ($port === 143 || !empty($cfg['plain'])) ? 'tcp://' : 'ssl://';
  $fp = @stream_socket_client($scheme . $host . ':' . $port, $eno, $estr, 15, STREAM_CLIENT_CONNECT, $ctx);
  if (!$fp) { $err = 'nu ma pot conecta la ' . $host . ':' . $port . ($estr ? ' (' . $estr . ')' : ''); return null; }
  stream_set_timeout($fp, 30);
  $g = fgets($fp); if ($g === false || stripos($g, '* OK') !== 0) { $err = 'serverul nu a raspuns ca un server IMAP'; fclose($fp); return null; }
  $n = 0;
  if ($scheme === 'tcp://' && empty($cfg['plain'])) {
    $r = az_imap_cmd($fp, $n, 'STARTTLS');
    if (!$r[0] || !@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) { $err = 'serverul nu accepta conexiune criptata (STARTTLS)'; fclose($fp); return null; }
  }
  $r = az_imap_cmd($fp, $n, 'LOGIN ' . az_imap_q($cfg['user']) . ' ' . az_imap_q($cfg['pass']));
  if (!$r[0]) { $err = 'autentificare respinsa de serverul de e-mail (utilizator sau parola)'; fclose($fp); return null; }
  return array($fp, $n);
}
function az_mail_cfg() { global $AZ_ROOT; return az_jload($AZ_ROOT . '/mail.json'); }
function az_mail_save($c) { global $AZ_ROOT; az_jsave($AZ_ROOT . '/mail.json', $c, 0600); @chmod($AZ_ROOT . '/mail.json', 0600); }

function az_mail_check($testOnly = false) {
  global $AZ_ROOT, $AZ_MAX;
  $cfg = az_mail_cfg(); $err = '';
  $lk = fopen($AZ_ROOT . '/mail.lock', 'c'); if ($lk && !flock($lk, LOCK_EX | LOCK_NB)) { fclose($lk); return $testOnly ? array('ok' => false, 'error' => 'o verificare a casutei este deja in curs; incercati din nou peste un minut') : array('ok' => true, 'busy' => true, 'noi' => array()); }
  if (@disk_free_space($AZ_ROOT) !== false && @disk_free_space($AZ_ROOT) < 200 * 1048576) { if ($lk) { flock($lk, LOCK_UN); fclose($lk); } return array('ok' => false, 'error' => 'spatiu insuficient pe server'); }
  $c = az_imap_open($cfg, $err);
  if (!$c) { $cfg['last_check'] = time(); $cfg['last_error'] = $err; if (isset($cfg['host'])) az_mail_save($cfg); if ($lk) { flock($lk, LOCK_UN); fclose($lk); } return array('ok' => false, 'error' => $err); }
  list($fp, $n) = $c; $noi = array(); $msgs = 0;
  $r = az_imap_cmd($fp, $n, 'SELECT INBOX');
  if (!$r[0]) { $err = 'nu pot deschide INBOX'; }
  else {
    $uv = ''; $exists = 0; foreach ($r[1] as $ln) { if (preg_match('/UIDVALIDITY (\d+)/', $ln, $m)) $uv = $m[1]; if (preg_match('/^\* (\d+) EXISTS/', $ln, $m)) $exists = (int)$m[1]; }
    if ($testOnly) { fwrite($fp, "A99 LOGOUT\r\n"); fclose($fp); $cfg['last_check'] = time(); $cfg['last_error'] = ''; az_mail_save($cfg); if ($lk) { flock($lk, LOCK_UN); fclose($lk); } return array('ok' => true, 'test' => true, 'mesaje' => $exists); }
    if (!isset($cfg['uidvalidity']) || $cfg['uidvalidity'] !== $uv) { $cfg['uidvalidity'] = $uv; $cfg['last_uid'] = 0; }
    $last = isset($cfg['last_uid']) ? (int)$cfg['last_uid'] : 0; $mids = isset($cfg['mids']) && is_array($cfg['mids']) ? $cfg['mids'] : array();
    $r = az_imap_cmd($fp, $n, 'UID SEARCH UID ' . ($last + 1) . ':*'); $uids = array();
    foreach ($r[1] as $ln) { if (preg_match('/^\* SEARCH(.*)$/i', trim($ln), $m)) { foreach (preg_split('/\s+/', trim($m[1])) as $u) { if ($u !== '' && (int)$u > $last) $uids[] = (int)$u; } } }
    sort($uids); $uids = array_slice($uids, 0, 25);
    foreach ($uids as $uid) {
      $sz = 0; $r = az_imap_cmd($fp, $n, 'UID FETCH ' . $uid . ' (RFC822.SIZE)'); foreach ($r[1] as $ln) { if (preg_match('/RFC822\.SIZE (\d+)/', $ln, $m)) $sz = (int)$m[1]; }
      if ($sz > 0 && $sz <= 25 * 1024 * 1024) {
        $r = az_imap_cmd($fp, $n, 'UID FETCH ' . $uid . ' (BODY.PEEK[])');
        if ($r[0] && isset($r[2][0])) {
          $cfg['last_uid'] = $uid; az_mail_save($cfg);          // inainte de prelucrare: un mesaj care da eroare nu mai blocheaza casuta
          $msg = az_msg_parse($r[2][0]); $key = sha1($msg['mid'] !== '' ? $msg['mid'] : $r[2][0]); $r = null;
          if (!in_array($key, $mids, true)) {
            $mids[] = $key; if (count($mids) > 800) $mids = array_slice($mids, -800);
            $rt = az_route($msg['to'], $msg['subj']); $ev = $rt[0]; $grup = az_id(); $ts = strtotime($msg['date']); $mdate = $ts ? date('Y-m-d H:i', $ts) : '';
            $base = array('ev' => $ev, 'src' => 'mail', 'from' => $msg['from'], 'subj' => $msg['subj'], 'mdate' => $mdate, 'grup' => $grup);
            $body = "De la: " . $msg['from'] . "\r\nData: " . $msg['date'] . "\r\nSubiect: " . $msg['subj'] . "\r\nRepartizat: " . $rt[1] . "\r\nAtasamente: " . count($msg['att']) . "\r\n\r\n" . $msg['text'];
            $tmp = $AZ_ROOT . '/tmp/m' . az_id(); file_put_contents($tmp, $body);
            $cl = az_clasifica('', $msg['subj'], $msg['from']);
            $rec = az_add_file($tmp, array_merge($base, array('name' => 'Mesaj – ' . az_name($msg['subj'] !== '' ? $msg['subj'] : 'fara subiect') . '.txt', 'tip' => 'corespondenta', 'inst' => $cl['inst'])), 'e-mail');
            if ($rec) $noi[] = $rec;
            $grp = array();
            foreach ($msg['att'] as $a) { if (strlen($a['data']) > $AZ_MAX) continue; $tmp = $AZ_ROOT . '/tmp/m' . az_id(); file_put_contents($tmp, $a['data']); $rec = az_add_file($tmp, array_merge($base, array('name' => $a['name'])), 'e-mail'); if ($rec) $grp[] = $rec; }
            // e-Factura (XML) + PDF-ul aceleiasi facturi in acelasi mesaj: sumele trec pe PDF, iar XML-ul ramane document insotitor (o singura factura la Financiar)
            $xmls = array(); $pdfs = array(); foreach ($grp as $g) { if (!empty($g['fin']['auto'])) $xmls[] = $g; elseif ($g['tip'] === 'factura' && preg_match('/\.pdf$/i', $g['name'])) $pdfs[] = $g; }
            if (count($xmls) === 1 && count($pdfs) === 1) {
              $xf = $xmls[0]; $pf = $pdfs[0];
              az_index_edit(function (&$ix) use ($xf, $pf) { $ix['files'][$pf['id']]['fin'] = $xf['fin']; $ix['files'][$xf['id']]['tip'] = 'document'; $ix['files'][$xf['id']]['nota'] = 'e-Factura (XML) a facturii ' . (isset($xf['fin']['nr']) ? $xf['fin']['nr'] : ''); unset($ix['files'][$xf['id']]['fin']); return true; });
              foreach ($grp as $gi => $g) { if ($g['id'] === $pf['id']) $grp[$gi]['fin'] = $xf['fin']; if ($g['id'] === $xf['id']) { $grp[$gi]['tip'] = 'document'; unset($grp[$gi]['fin']); } }
            }
            foreach ($grp as $g) $noi[] = $g;
            $msgs++;
          }
          az_imap_cmd($fp, $n, 'UID STORE ' . $uid . ' +FLAGS (\\Seen)');
        }
      }
      $cfg['last_uid'] = $uid; $cfg['mids'] = $mids; az_mail_save($cfg);
    }
    $cfg['mids'] = $mids;
  }
  fwrite($fp, 'A' . ($n + 1) . " LOGOUT\r\n"); fclose($fp);
  $cfg['last_check'] = time(); $cfg['last_error'] = $err; $cfg['last_count'] = count($noi); if ($msgs) $cfg['total_msgs'] = (isset($cfg['total_msgs']) ? (int)$cfg['total_msgs'] : 0) + $msgs;
  az_mail_save($cfg); if ($lk) { flock($lk, LOCK_UN); fclose($lk); }
  return $err !== '' ? array('ok' => false, 'error' => $err) : array('ok' => true, 'noi' => $noi, 'mesaje' => $msgs);
}

/* ================= intrare ================= */
az_mkdirs();
if (PHP_SAPI === 'cli') {
  az_migrate();            // pentru cron: php -q autorizari.php cron
  if (isset($argv[1]) && $argv[1] === 'cron') { $r = az_mail_check(false); echo ($r['ok'] ? 'ok ' . (isset($r['noi']) ? count($r['noi']) : 0) . ' documente noi' : 'eroare: ' . $r['error']) . "\n"; }
  exit;
}
$me = az_session();
if (!$me) { az_fail(401, 'no_session'); }
$a = isset($_GET['a']) ? $_GET['a'] : '';
$method = $_SERVER['REQUEST_METHOD'];
$isOwner = az_owner($me);
if ($isOwner) az_migrate();            // prima deschidere cu contul owner muta evenimentele din starea comuna pe companii
$C = az_co();
$who = isset($me['name']) && $me['name'] !== '' ? $me['name'] : (isset($me['user']) ? $me['user'] : '');

if ($a === 'caps') {
  $c = az_mail_cfg();
  az_out(array('ok' => true, 'php' => $isOwner ? PHP_VERSION : '', 'owner' => $isOwner, 'user' => isset($me['user']) ? $me['user'] : '', 'nume' => $who, 'rol' => isset($me['role']) ? $me['role'] : '', 'v' => '0.11', 'max' => $AZ_MAX, 'chunk' => 1024 * 1024, 'xml' => function_exists('simplexml_load_string'), 'ssl' => extension_loaded('openssl'),
    'mail' => array('configurat' => !empty($c['host']) && !empty($c['user']) && !empty($c['pass']), 'adresa' => isset($c['addr']) ? $c['addr'] : '', 'last_check' => isset($c['last_check']) ? $c['last_check'] : 0, 'last_error' => $isOwner && isset($c['last_error']) ? $c['last_error'] : '', 'total' => isset($c['total_msgs']) ? $c['total_msgs'] : 0)));
}

/* ---------- evenimente si companii ---------- */
if ($a === 'evs') {
  if ($isOwner && !$C['list']) { az_co_edit(function (&$c) use ($who) { if (!$c['list']) az_co_find_or_add($c, '', array(), $who); return true; }); $C = az_co(); }
  $cos = array(); foreach ($C['list'] as $id => $c) { $d = az_drept($me, (string)$id, $C); if ($d > 0) { $c['id'] = (string)$id; $c['drept'] = $d; $cos[] = $c; } }
  usort($cos, function ($x, $y) { return strcasecmp($x['nume'], $y['nume']); });
  $evs = array(); $del = array();
  foreach (az_ev_all() as $e) {
    $d = az_drept($me, $e['co'], $C); if ($d < 1) continue;
    if (!empty($e['del'])) { if ($d >= 3) { $x = json_decode($e['data'], true); $del[] = array('id' => $e['id'], 'co' => $e['co'], 'nume' => is_array($x) && isset($x['nume']) && is_scalar($x['nume']) ? (string)$x['nume'] : '', 'start' => is_array($x) && isset($x['start']) && is_scalar($x['start']) ? (string)$x['start'] : '', 'del' => (int)$e['del'], 'del_by' => isset($e['del_by']) ? $e['del_by'] : ''); } continue; }
    $evs[] = az_ev_pub($e);
  }
  az_out(array('ok' => true, 'me' => array('user' => isset($me['user']) ? $me['user'] : '', 'name' => $who, 'role' => isset($me['role']) ? $me['role'] : '', 'owner' => $isOwner), 'companii' => $cos, 'events' => $evs, 'sterse' => $del));
}
if ($a === 'evput' && $method === 'POST') {
  $raw = file_get_contents('php://input'); if (strlen($raw) > 3000000) az_fail(413, 'evenimentul are prea multe date');
  $in = json_decode($raw, true);
  if (!is_array($in) || empty($in['id']) || !az_okevid($in['id']) || !isset($in['data']) || !is_string($in['data'])) az_fail(400, 'bad_request');
  $d = json_decode($in['data']); if (!is_object($d) || !isset($d->id) || $d->id !== $in['id']) az_fail(400, 'datele evenimentului nu sunt valide');
  $co = isset($in['co']) && is_string($in['co']) ? $in['co'] : ''; $rev = isset($in['rev']) ? (int)$in['rev'] : 0;
  $res = az_ev_edit($in['id'], function ($cur) use ($in, $me, $who, $C, $co, $rev) {
    if ($cur) {
      if (az_drept($me, $cur['co'], $C) < 2) return array('__err' => array(403, 'nu aveti drept de modificare la acest eveniment'));
      if (!empty($cur['del'])) return array('__err' => array(410, 'evenimentul a fost sters'));
      if ($rev !== (int)$cur['rev']) return array('__err' => array(409, 'conflict'), 'cur' => $cur);
      $nco = $cur['co'];
      if ($co !== '' && $co !== $cur['co']) {
        if (!isset($C['list'][$co])) return array('__err' => array(400, 'compania aleasa nu exista'));
        if (az_drept($me, $co, $C) < 3 || az_drept($me, $cur['co'], $C) < 3) return array('__err' => array(403, 'mutarea la alta companie cere drept de administrare la amandoua'));
        $nco = $co;
      }
      $cur['co'] = $nco; $cur['rev'] = (int)$cur['rev'] + 1; $cur['ts'] = time(); $cur['by'] = $who; $cur['data'] = $in['data'];
      return $cur;
    }
    if ($co === '' || !isset($C['list'][$co])) return array('__err' => array(400, 'alegeti compania evenimentului'));
    if (az_drept($me, $co, $C) < 2) return array('__err' => array(403, 'nu aveti drept sa adaugati evenimente la aceasta companie'));
    if (!az_owner($me)) { foreach (az_index() as $f) { if (isset($f['ev']) && $f['ev'] === $in['id']) return array('__err' => array(409, 'acest identificator de eveniment este deja folosit')); } }
    return array('id' => $in['id'], 'co' => $co, 'rev' => 1, 'ts' => time(), 'by' => $who, 'creat' => time(), 'de' => $who, 'data' => $in['data']);
  });
  if (isset($res['__err'])) az_fail($res['__err'][0], $res['__err'][1], isset($res['cur']) ? array('conflict' => true, 'ev' => az_ev_pub($res['cur'])) : array());
  az_out(array('ok' => true, 'ev' => array('id' => $res['id'], 'co' => $res['co'], 'rev' => (int)$res['rev'], 'ts' => (int)$res['ts'], 'by' => $res['by'])));
}
if (($a === 'evdel' || $a === 'evrestore') && $method === 'POST') {
  $in = json_decode(file_get_contents('php://input'), true); if (!is_array($in) || empty($in['id']) || !az_okevid($in['id'])) az_fail(400, 'bad_request');
  $res = az_ev_edit($in['id'], function ($cur) use ($me, $who, $C, $a) {
    if (!$cur) return array('__err' => array(404, 'evenimentul nu exista'));
    if (az_drept($me, $cur['co'], $C) < 3) return array('__err' => array(403, 'stergerea si restaurarea cer drept de administrare pe companie'));
    if ($a === 'evdel') { $cur['del'] = time(); $cur['del_by'] = $who; }
    else { unset($cur['del'], $cur['del_by']); $cur['rev'] = (int)$cur['rev'] + 1; $cur['ts'] = time(); }
    return $cur;
  });
  if (isset($res['__err'])) az_fail($res['__err'][0], $res['__err'][1]);
  az_out(array('ok' => true));
}
if ($a === 'evpurge' && $method === 'POST') {      // scoatere definitiva din aplicatie: fisierul evenimentului trece in data/autorizari/sterse (nu se distruge)
  if (!$isOwner) az_fail(403, 'doar contul owner poate scoate definitiv un eveniment');
  $in = json_decode(file_get_contents('php://input'), true); if (!is_array($in) || empty($in['id']) || !az_okevid($in['id'])) az_fail(400, 'bad_request');
  $lk = fopen($AZ_ROOT . '/ev.lock', 'c'); if ($lk) flock($lk, LOCK_EX);
  $cur = az_ev_get($in['id']); $ok = false; $msg = 'evenimentul nu exista';
  if ($cur && empty($cur['del'])) $msg = 'intai se sterge evenimentul; abia apoi poate fi scos definitiv';
  elseif ($cur) { $ok = @rename(az_ev_path($in['id']), $AZ_ROOT . '/sterse/ev_' . $in['id'] . '_' . date('Ymd_His') . '.json'); $msg = 'nu am putut muta fisierul'; }
  if ($lk) { flock($lk, LOCK_UN); fclose($lk); }
  if (!$ok) az_fail(400, $msg);
  $pid = $in['id']; az_index_edit(function (&$ix) use ($pid, $who) { foreach ($ix['files'] as $k => $f) { if (isset($f['ev']) && $f['ev'] === $pid && empty($f['del'])) { $ix['files'][$k]['del'] = time(); $ix['files'][$k]['del_by'] = $who . ' (eveniment scos)'; } } return true; });
  az_out(array('ok' => true));
}
if ($a === 'cos') {
  if (!$isOwner) az_fail(403, 'doar contul owner administreaza companiile si accesul');
  $nev = array(); foreach (az_ev_all() as $e) { $nev[$e['co']] = (isset($nev[$e['co']]) ? $nev[$e['co']] : 0) + 1; }
  $cos = array(); foreach ($C['list'] as $id => $c) { $c['id'] = (string)$id; $c['ev'] = isset($nev[$id]) ? $nev[$id] : 0; $cos[] = $c; }
  usort($cos, function ($x, $y) { return strcasecmp($x['nume'], $y['nume']); });
  $users = array(); foreach (az_jload($AZ_DIR . '/users.json') as $u) { if (is_array($u) && isset($u['user'])) $users[] = array('user' => (string)$u['user'], 'name' => isset($u['name']) ? (string)$u['name'] : (string)$u['user'], 'role' => isset($u['role']) ? (string)$u['role'] : 'staff'); }
  $acc = array(); foreach ($C['acces'] as $u => $m) { if (is_array($m) && $m) $acc[(string)$u] = $m; }
  az_out(array('ok' => true, 'companii' => $cos, 'acces' => $acc ? $acc : new stdClass(), 'users' => $users));
}
if ($a === 'coput' && $method === 'POST') {
  if (!$isOwner) az_fail(403, 'doar contul owner administreaza companiile');
  $in = json_decode(file_get_contents('php://input'), true); if (!is_array($in)) az_fail(400, 'bad_request');
  $nume = az_txt(isset($in['nume']) ? $in['nume'] : '', 160); if ($nume === '') az_fail(400, 'scrieti denumirea companiei');
  $id = isset($in['id']) && $in['id'] !== '' ? $in['id'] : ''; if ($id !== '' && !az_okco($id)) az_fail(400, 'bad_id');
  $rec = az_co_edit(function (&$c) use ($in, $nume, $id, $who) {
    if ($id !== '' && !isset($c['list'][$id])) return null;
    foreach ($c['list'] as $k => $x) { if ((string)$k !== $id && az_co_key(isset($x['nume']) ? $x['nume'] : '') === az_co_key($nume)) return array('__dup' => true); }
    if ($id === '') { $id = 'c' . bin2hex(random_bytes(6)); $c['list'][$id] = array('id' => $id, 'creat' => time(), 'de' => $who); }
    $r = $c['list'][$id]; $r['id'] = $id; $r['nume'] = $nume;
    foreach (array('cui', 'j', 'sediu', 'rep', 'functie', 'tel', 'email') as $f) { if (isset($in[$f])) { $v = az_txt($in[$f], 300); if ($v === '') unset($r[$f]); else $r[$f] = $v; } }
    $c['list'][$id] = $r; return $r;
  });
  if (!$rec) az_fail(404, 'compania nu exista sau nu am putut salva');
  if (isset($rec['__dup'])) az_fail(409, 'exista deja o companie cu aceasta denumire');
  az_out(array('ok' => true, 'companie' => $rec));
}
if ($a === 'codel' && $method === 'POST') {
  if (!$isOwner) az_fail(403, 'doar contul owner administreaza companiile');
  $in = json_decode(file_get_contents('php://input'), true); if (!is_array($in) || empty($in['id']) || !az_okco($in['id'])) az_fail(400, 'bad_request');
  foreach (az_ev_all() as $e) { if ($e['co'] === $in['id']) az_fail(409, 'compania are evenimente (active sau sterse); mutati-le intai la alta companie'); }
  $ok = az_co_edit(function (&$c) use ($in) { if (!isset($c['list'][$in['id']])) return null; unset($c['list'][$in['id']]); foreach ($c['acces'] as $u => $m) { if (is_array($m)) { unset($c['acces'][$u][$in['id']]); if (!$c['acces'][$u]) unset($c['acces'][$u]); } } return true; });
  if (!$ok) az_fail(404, 'compania nu exista');
  az_out(array('ok' => true));
}
if ($a === 'acces' && $method === 'POST') {
  if (!$isOwner) az_fail(403, 'doar contul owner da si retrage accesul');
  $in = json_decode(file_get_contents('php://input'), true); if (!is_array($in) || empty($in['user']) || !is_string($in['user']) || empty($in['co']) || !az_okco($in['co'])) az_fail(400, 'bad_request');
  $drept = isset($in['drept']) ? (string)$in['drept'] : ''; if (!in_array($drept, array('', 'view', 'edit', 'admin'), true)) az_fail(400, 'drept necunoscut');
  $exista = false; foreach (az_jload($AZ_DIR . '/users.json') as $u) { if (is_array($u) && isset($u['user']) && $u['user'] === $in['user']) $exista = true; }
  if (!$exista) az_fail(404, 'utilizatorul nu exista');
  $ok = az_co_edit(function (&$c) use ($in, $drept) {
    if (!isset($c['list'][$in['co']])) return null;
    if (!isset($c['acces'][$in['user']]) || !is_array($c['acces'][$in['user']])) $c['acces'][$in['user']] = array();
    if ($drept === '') { unset($c['acces'][$in['user']][$in['co']]); if (!$c['acces'][$in['user']]) unset($c['acces'][$in['user']]); }
    else $c['acces'][$in['user']][$in['co']] = $drept;
    return true;
  });
  if (!$ok) az_fail(404, 'compania nu exista');
  az_out(array('ok' => true));
}

/* ---------- arhiva: fiecare actiune verifica dreptul asupra evenimentului de care tine fisierul ---------- */
if ($a === 'list') {
  $ev = isset($_GET['ev']) ? $_GET['ev'] : ''; $out = array();
  if ($ev === '' ? !$isOwner : az_ev_drept($me, $ev, $C) < 1) az_fail(403, 'nu aveti acces la documentele acestui eveniment');
  $inb = az_ev_drept($me, '_inbox', $C) >= 1;
  foreach (az_index() as $r) { if (!empty($r['del'])) continue; if ($r['ev'] === '_inbox' ? !$inb : ($ev !== '' && $r['ev'] !== $ev)) continue; $out[] = $r; }
  usort($out, function ($x, $y) { return strcmp($x['inst'] . $x['cod'] . $x['name'], $y['inst'] . $y['cod'] . $y['name']); });
  az_out(array('ok' => true, 'files' => $out));
}
if ($a === 'begin' && $method === 'POST') {
  $in = json_decode(file_get_contents('php://input'), true); if (!is_array($in)) az_fail(400, 'bad_request');
  if (empty($in['ev']) || !az_okev($in['ev'])) az_fail(400, 'eveniment lipsa');
  if (az_ev_drept($me, $in['ev'], $C) < 2) az_fail(403, 'nu aveti drept de modificare la acest eveniment');
  unset($in['id'], $in['src'], $in['from'], $in['subj'], $in['mdate'], $in['grup']);
  if (@disk_free_space($AZ_ROOT) !== false && @disk_free_space($AZ_ROOT) < 200 * 1048576) az_fail(507, 'spatiu insuficient pe server');
  $total = isset($in['total']) ? (int)$in['total'] : 0; if ($total < 0 || $total > $AZ_MAX) az_fail(413, 'fisier prea mare (maximum ' . round($AZ_MAX / 1048576) . ' MB)');
  if ($total === 0) { $rec = az_add_file(null, $in, $who); if (!$rec) az_fail(500, 'nu am putut salva'); az_out(array('ok' => true, 'file' => $rec)); }
  $id = az_id(); $in['id'] = $id; $in['total'] = $total;
  file_put_contents($AZ_ROOT . '/tmp/' . $id . '.json', json_encode($in)); file_put_contents($AZ_ROOT . '/tmp/' . $id . '.part', '');
  az_out(array('ok' => true, 'id' => $id));
}
if ($a === 'put' && $method === 'POST') {
  $id = isset($_GET['id']) ? $_GET['id'] : ''; if (!az_okid($id)) az_fail(400, 'bad_id');
  $pf = $AZ_ROOT . '/tmp/' . $id . '.part'; $mf = $AZ_ROOT . '/tmp/' . $id . '.json'; if (!is_file($pf) || !is_file($mf)) az_fail(404, 'incarcare necunoscuta');
  $meta = az_jload($mf); $off = isset($_GET['off']) ? (int)$_GET['off'] : 0;
  if (!isset($meta['ev']) || az_ev_drept($me, $meta['ev'], $C) < 2) az_fail(403, 'nu aveti drept de modificare la acest eveniment');
  $data = file_get_contents('php://input'); $len = strlen($data);
  $ph = fopen($pf, 'ab'); if (!$ph || !flock($ph, LOCK_EX)) az_fail(500, 'nu pot scrie');
  clearstatcache(); $have = filesize($pf);
  if ($off !== $have) { flock($ph, LOCK_UN); fclose($ph); az_fail(409, 'offset', array('have' => $have)); }
  if ($len === 0 || $len > $AZ_CHUNK || $have + $len > (int)$meta['total']) { flock($ph, LOCK_UN); fclose($ph); az_fail(400, 'bucata invalida'); }
  $w = fwrite($ph, $data); fflush($ph); flock($ph, LOCK_UN); fclose($ph);
  if ($w !== $len) az_fail(507, 'scriere incompleta (spatiu pe server?)');
  if ($have + $len < (int)$meta['total']) az_out(array('ok' => true, 'have' => $have + $len));
  @unlink($mf); $rec = az_add_file($pf, $meta, $who); if (!$rec) az_fail(500, 'nu am putut salva fisierul');
  az_out(array('ok' => true, 'done' => true, 'file' => $rec));
}
if ($a === 'get') {
  $id = isset($_GET['id']) ? $_GET['id'] : ''; if (!az_okid($id)) az_fail(400, 'bad_id');
  $ix = az_index(); if (!isset($ix[$id]) || !empty($ix[$id]['del'])) az_fail(404, 'not_found');
  if (az_ev_drept($me, $ix[$id]['ev'], $C) < 1) az_fail(403, 'nu aveti acces la acest document');
  $p = $AZ_ROOT . '/f/' . $id; if (!is_file($p)) az_fail(404, 'not_found');
  $ext = strtolower(pathinfo($ix[$id]['name'], PATHINFO_EXTENSION));
  $types = array('pdf' => 'application/pdf', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'webp' => 'image/webp', 'gif' => 'image/gif', 'txt' => 'text/plain; charset=utf-8', 'xml' => 'text/plain; charset=utf-8', 'csv' => 'text/plain; charset=utf-8');
  header('Content-Type: ' . (isset($types[$ext]) ? $types[$ext] : 'application/octet-stream')); header('X-Content-Type-Options: nosniff'); header('Cache-Control: private, no-store');
  header('Content-Length: ' . filesize($p)); header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode($ix[$id]['name']));
  readfile($p); exit;
}
if ($a === 'meta' && $method === 'POST') {
  $in = json_decode(file_get_contents('php://input'), true); if (!is_array($in) || empty($in['id']) || !az_okid($in['id']) || !isset($in['patch']) || !is_array($in['patch'])) az_fail(400, 'bad_request');
  $p = $in['patch'];
  $ix0 = az_index(); if (!isset($ix0[$in['id']])) az_fail(404, 'not_found');
  if (az_ev_drept($me, $ix0[$in['id']]['ev'], $C) < 2) az_fail(403, 'nu aveti drept de modificare la acest document');
  if (isset($p['ev']) && az_okev($p['ev']) && az_ev_drept($me, $p['ev'], $C) < 2) az_fail(403, 'nu aveti drept de modificare la evenimentul ales');
  $ev0 = $ix0[$in['id']]['ev'];
  $rec = az_index_edit(function (&$ix) use ($in, $p, $ev0) {
    if (!isset($ix['files'][$in['id']]) || $ix['files'][$in['id']]['ev'] !== $ev0) return null; $r = $ix['files'][$in['id']];
    if (isset($p['ev']) && az_okev($p['ev'])) $r['ev'] = $p['ev'];
    if (isset($p['inst'])) $r['inst'] = substr(preg_replace('/[^A-Z]/', '', strtoupper($p['inst'])), 0, 10);
    if (isset($p['tip'])) $r['tip'] = substr(preg_replace('/[^a-z]/', '', strtolower($p['tip'])), 0, 16);
    if (isset($p['cod'])) $r['cod'] = $p['cod'] === '' ? '' : substr(az_name($p['cod']), 0, 24);
    if (isset($p['nota'])) $r['nota'] = function_exists('mb_substr') ? mb_substr((string)$p['nota'], 0, 300, 'UTF-8') : substr((string)$p['nota'], 0, 300);
    if (isset($p['fin']) && is_array($p['fin'])) $r['fin'] = az_fin_clean(array_merge(isset($r['fin']) ? $r['fin'] : array(), $p['fin']));
    if (isset($p['fin']) && is_array($p['fin'])) { foreach ($p['fin'] as $fk => $fv) { if ($fv === '' || $fv === false || $fv === null) unset($r['fin'][$fk]); } }
    if (isset($r['fin']) && !$r['fin']) unset($r['fin']);
    $ix['files'][$in['id']] = $r; return $r;
  });
  if (!$rec) az_fail(404, 'not_found'); az_out(array('ok' => true, 'file' => $rec));
}
if ($a === 'del' && $method === 'POST') {
  $in = json_decode(file_get_contents('php://input'), true); if (!is_array($in) || empty($in['id']) || !az_okid($in['id'])) az_fail(400, 'bad_request');
  $ix0 = az_index(); if (!isset($ix0[$in['id']])) az_fail(404, 'not_found');
  if (az_ev_drept($me, $ix0[$in['id']]['ev'], $C) < 2) az_fail(403, 'nu aveti drept de modificare la acest document');
  $ev0 = $ix0[$in['id']]['ev'];
  $ok = az_index_edit(function (&$ix) use ($in, $who, $ev0) { if (!isset($ix['files'][$in['id']]) || $ix['files'][$in['id']]['ev'] !== $ev0) return false; $ix['files'][$in['id']]['del'] = time(); $ix['files'][$in['id']]['del_by'] = $who; return true; });
  if ($ok && is_file($AZ_ROOT . '/f/' . $in['id'])) @rename($AZ_ROOT . '/f/' . $in['id'], $AZ_ROOT . '/sterse/' . $in['id']);   // nu se sterge definitiv: ramane in data/autorizari/sterse
  az_out(array('ok' => (bool)$ok));
}
if ($a === 'mailcfg') {
  $c = az_mail_cfg();
  if ($method === 'POST') {
    if (!$isOwner) az_fail(403, 'doar contul owner poate configura casuta de e-mail');
    $in = json_decode(file_get_contents('php://input'), true); if (!is_array($in)) az_fail(400, 'bad_request');
    foreach (array('host', 'user', 'addr', 'pass') as $k) { if (isset($in[$k]) && (!is_string($in[$k]) || preg_match('/[\r\n\0]/', $in[$k]))) az_fail(400, 'valoare nepermisa in ' . $k); }
    if (isset($in['host']) && $in['host'] !== '' && !preg_match('/^[A-Za-z0-9.-]{1,120}\z/D', trim($in['host']))) az_fail(400, 'numele serverului nu este valid');
    foreach (array('host', 'user', 'addr') as $k) { if (isset($in[$k])) $c[$k] = substr(trim((string)$in[$k]), 0, 120); }
    if (isset($in['port'])) $c['port'] = max(1, min(65535, (int)$in['port']));
    $c['noverify'] = !empty($in['noverify']);
    if (isset($in['pass']) && $in['pass'] !== '') $c['pass'] = (string)$in['pass'];
    if (!empty($in['sterge'])) { $c = array(); }
    az_mail_save($c);
    $t = empty($c['host']) ? array('ok' => true) : az_mail_check(true);
    az_out(array('ok' => !empty($t['ok']), 'error' => isset($t['error']) ? $t['error'] : '', 'mesaje' => isset($t['mesaje']) ? $t['mesaje'] : 0));
  }
  if (!$isOwner) az_out(array('ok' => true, 'owner' => false, 'addr' => isset($c['addr']) ? $c['addr'] : ''));
  az_out(array('ok' => true, 'owner' => $isOwner, 'host' => isset($c['host']) ? $c['host'] : '', 'port' => isset($c['port']) ? $c['port'] : 993, 'user' => isset($c['user']) ? $c['user'] : '', 'addr' => isset($c['addr']) ? $c['addr'] : '', 'noverify' => !empty($c['noverify']),
    'are_parola' => !empty($c['pass']), 'last_check' => isset($c['last_check']) ? $c['last_check'] : 0, 'last_error' => isset($c['last_error']) ? $c['last_error'] : '', 'total' => isset($c['total_msgs']) ? $c['total_msgs'] : 0, 'cron' => $isOwner ? 'php -q ' . __FILE__ . ' cron' : ''));
}
if ($a === 'mailcheck' && $method === 'POST') { if (az_drept_max($me, $C) < 2) az_fail(403, 'nu aveti drept de modificare'); $r = az_mail_check(false); if (isset($r['noi']) && is_array($r['noi'])) $r['noi'] = array_fill(0, count($r['noi']), 1); az_out($r); }
az_fail(400, 'actiune necunoscuta');
