<?php
/* Universul HoReCa — Roadmap: primire mesaje/idei din pagina roadmap.html.
   POST {nume,mesaj,sectiune} -> adauga in data/roadmap.json.
   GET  ?key=UHROAD2026     -> returneaza lista (pentru pagina + pentru Claude).
   GET  fara key            -> doar numarul de mesaje. */
header('Content-Type: application/json; charset=utf-8');
$dir = __DIR__ . '/data';
if (!is_dir($dir)) @mkdir($dir, 0775, true);
$f = $dir . '/roadmap.json';
$KEY = 'UHROAD2026';
$method = $_SERVER['REQUEST_METHOD'];

function load($f){ if(!is_file($f)) return array(); $j=json_decode(file_get_contents($f),true); return is_array($j)?$j:array(); }

if ($method === 'POST') {
  $raw = file_get_contents('php://input');
  if (strlen($raw) > 20000) { http_response_code(413); echo json_encode(array('error'=>'too_large')); exit; }
  $in = json_decode($raw, true);
  if (!is_array($in) || !isset($in['mesaj']) || trim($in['mesaj']) === '') {
    http_response_code(400); echo json_encode(array('error'=>'bad_request')); exit;
  }
  $list = load($f);
  $ipHash = hash('sha256', (isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'') . 'uh-road-salt');
  $now = time(); $recent = 0;
  foreach ($list as $m) { if (isset($m['ip']) && $m['ip']===$ipHash && ($now - (int)$m['ts']) < 600) $recent++; }
  if ($recent >= 30) { http_response_code(429); echo json_encode(array('error'=>'rate_limited')); exit; }

  $entry = array(
    'id'       => uniqid('road_'),
    'nume'     => mb_substr(trim(isset($in['nume'])?$in['nume']:''), 0, 120),
    'sectiune' => mb_substr(trim(isset($in['sectiune'])?$in['sectiune']:'evenimente'), 0, 60),
    'mesaj'    => mb_substr(trim($in['mesaj']), 0, 6000),
    'stare'    => 'nou',
    'ts'       => $now,
    'ip'       => $ipHash
  );
  $list[] = $entry;
  if (count($list) > 2000) $list = array_slice($list, -2000);
  file_put_contents($f, json_encode($list, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
  echo json_encode(array('ok'=>true, 'id'=>$entry['id']));
  exit;
}

if ($method === 'GET') {
  $list = load($f);
  if (isset($_GET['key']) && $_GET['key'] === $KEY) {
    // returneaza mesajele fara hash-ul de IP
    $out = array();
    foreach ($list as $m) { unset($m['ip']); $out[] = $m; }
    echo json_encode(array('ok'=>true, 'count'=>count($out), 'items'=>$out), JSON_UNESCAPED_UNICODE);
  } else {
    echo json_encode(array('ok'=>true, 'count'=>count($list)));
  }
  exit;
}

http_response_code(405);
echo json_encode(array('error'=>'method_not_allowed'));
