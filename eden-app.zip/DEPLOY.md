# EDEN — Punere online & actualizări

## Ce e nou: Consola de Update (`admin.html`)
După prima punere online, **nu mai ai nevoie de FTP**. Intri la `…/eden/admin.html`, te loghezi cu contul **owner** și de acolo:
- **Publici versiuni noi** — tragi `eden-app.zip` (sau fișiere individuale: `index.html`, `app.html`, `sw.js`, iconițe) și apeși **Publică**. Se face **backup automat** înainte de suprascriere.
- **Editezi `version.json`** — versiune, canal, note.
- **Forțezi update pe toate dispozitivele** — un buton care înnoiește cache-ul (Service Worker); telefoanele/desktop-urile trag versiunea nouă la următoarea deschidere online.
- **Gestionezi utilizatori** — vezi cine are 2FA / conturi legate, adaugi conturi.
- Fișierele `.php` **nu pot fi încărcate** prin consolă (protecție anti-abuz).

## Punerea online — o singură dată (bootstrap)
Consola trebuie urcată prima dată manual. Ai nevoie de o găzduire cu **PHP 7+** (ideal 8.x). Pași:

1. **Certificat SSL activ** pe domeniu (HTTPS). Indicatorul SSL din aplicație devine verde când e ok.
2. Urcă tot conținutul folderului `eden-pwa/` în directorul web (ex: `public_html/eden/`), via:
   - File Manager din panoul găzduirii (cPanel/Plesk/DirectAdmin), **sau**
   - FTP/SFTP (FileZilla), **sau**
   - `git clone` + `git pull` dacă hostul permite.
3. Verifică permisiunile: folderul `data/` trebuie să fie **scriibil** de PHP (0755/0775). Aici se scriu conturile, sesiunile și backup-urile. `data/.htaccess` blochează accesul web la el (rămâne așa).
4. Setează `app.base_url` în `data/auth_config.json` (copiat din `.sample`) dacă folosești Google/Facebook/WhatsApp.
5. Deschide `…/eden/index.html` → creează contul **Owner** (primul cont). Gata.

Din acest moment, **toate actualizările** viitoare le faci din `admin.html`, fără să mai atingi FTP-ul.

## Fluxul de update recomandat
1. Primești de la mine `eden-app.zip` (versiunea nouă).
2. `admin.html` → **Publică** → tragi zip-ul → **Publică**.
3. Verifici versiunea în „Stare sistem".
4. Apeși **Forțează update pe toate dispozitivele**.

## Note de siguranță
- Consola e **doar pentru owner** (sesiune verificată pe server). Staff/manager nu au acces.
- Recomand **2FA (Google Authenticator)** pe contul owner — activezi din aplicație (butonul 🔒 2FA) sau te loghezi cu cod la consolă.
- Backup-urile se strâng în `data/backups/` — le poți descărca/curăța periodic din File Manager.
