<?php
// EDEN OS — Consola de Update (backend). DOAR owner. Permite actualizarea aplicatiei din browser.
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$ROOT = __DIR__;
$dir  = $ROOT . '/data';
$usersF = $dir . '/users.json';
$sessF  = $dir . '/sessions.json';
$bkDir  = $dir . '/backups';

function jload($f){ return is_file($f) ? json_decode(file_get_contents($f), true) : array(); }
function out($d){ echo json_encode($d); exit; }
function fail($code,$msg){ http_response_code($code); echo json_encode(array('error'=>$msg)); exit; }

// --- sesiune + owner ---
function owner_or_die(){
  global $sessF, $usersF;
  $tok = isset($_SERVER['HTTP_X_EDEN_SESSION']) ? $_SERVER['HTTP_X_EDEN_SESSION'] : '';
  if(!$tok) fail(401,'no_session');
  $s=jload($sessF); if(!isset($s[$tok]) || $s[$tok]['exp']<time()) fail(401,'no_session');
  if($s[$tok]['role']!=='owner') fail(403,'forbidden');
  return $s[$tok];
}

// fisiere pe care consola are voie sa le scrie (fara .php, fara traversare)
function allowed_target($name){
  $name = str_replace('\\','/',$name);
  if(strpos($name,'..')!==false) return false;
  $name = ltrim($name,'/');
  // whitelist by extension + prefix
  if(preg_match('#\.php$#i',$name)) return false;                   // niciodata cod backend
  $okExt = array('html','js','json','webmanifest','png','ico','svg','css','md','txt','map','woff','woff2');
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  if(!in_array($ext,$okExt)) return false;
  // doar in radacina app sau in icons/
  if(strpos($name,'/')!==false && strpos($name,'icons/')!==0) return false;
  if($name==='auth_config.json') return false;
  return $name;
}
function jsave2($f,$d){ $t=$f.'.tmp'; file_put_contents($t,json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX); rename($t,$f); }
function ver_gt($a,$b){ $a=preg_split('/[._-]/',(string)$a); $b=preg_split('/[._-]/',(string)$b); for($i=0;$i<max(count($a),count($b));$i++){ $x=intval(isset($a[$i])?$a[$i]:0); $y=intval(isset($b[$i])?$b[$i]:0); if($x!=$y) return $x>$y; } return false; }
function http_get_raw($url,&$code){ $ch=curl_init($url); curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_TIMEOUT=>60,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_USERAGENT=>'EDEN-OS-Updater')); $r=curl_exec($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch); return $r; }


// scriere sigura: fisier temporar in acelasi dosar + rename (merge si cand fisierul vechi nu e al procesului PHP, ex. dupa mutarea pe alt server)
function write_atomic($dest,$data,&$why){
  $why='';
  $dir=dirname($dest);
  $tmp=$dir.'/.eden-upd-'.bin2hex(random_bytes(4)).'.tmp';
  if(@file_put_contents($tmp,$data)!==false){
    @chmod($tmp,0644);
    if(@rename($tmp,$dest)) return true;
    if(is_file($dest) && @unlink($dest) && @rename($tmp,$dest)) return true;
    @unlink($tmp);
  }
  if(@file_put_contents($dest,$data)!==false) return true;
  $e=error_get_last();
  $why=(!is_writable($dir)?'dosar_fara_drept_de_scriere':(is_file($dest)&&!is_writable($dest)?'fisier_fara_drept_de_scriere':'scriere_esuata')).($e?(': '.$e['message']):'');
  return false;
}
function apply_zip($za,$ROOT){
  $written=array(); $skipped=array(); $errors=array();
  $n=$za->numFiles; for($i=0;$i<$n;$i++){
    $st=$za->statIndex($i); $nm=$st['name']; if(substr($nm,-1)==='/') continue;
    $rel=preg_replace('#^eden-pwa/#','',$nm);
    $t=allowed_target($rel); if($t===false){ $skipped[]=$rel; continue; }
    $d=$za->getFromIndex($i); if($d===false){ $errors[]=array('file'=>$rel,'why'=>'nu_se_citeste_din_arhiva'); continue; }
    $dest=$ROOT.'/'.$t; if(strpos($t,'icons/')===0 && !is_dir($ROOT.'/icons')) @mkdir($ROOT.'/icons',0755,true);
    $why=''; if(write_atomic($dest,$d,$why)) $written[]=$t; else $errors[]=array('file'=>$t,'why'=>$why);
  }
  if($n===0) $errors[]=array('file'=>'(arhiva)','why'=>'arhiva_goala_sau_necitita');
  return array($written,$skipped,$errors);
}

$action = isset($_GET['action']) ? $_GET['action'] : '';
$raw = file_get_contents('php://input');
$in = json_decode($raw, true); if(!is_array($in)) $in=array();
if($action==='' && isset($in['action'])) $action=$in['action'];

// ---------- who am I ----------
if($action==='admin_me'){ $me=owner_or_die(); out(array('ok'=>true,'user'=>$me['user'],'name'=>$me['name'],'role'=>$me['role'])); }

// ---------- status: versiune + fisiere ----------
if($action==='admin_status'){
  owner_or_die();
  $ver = jload($ROOT.'/version.json');
  $files=array();
  $scan=function($base,$prefix) use (&$files,$ROOT){
    foreach(scandir($base) as $f){ if($f==='.'||$f==='..')continue; $p=$base.'/'.$f; if(is_file($p)){ $files[]=array('name'=>$prefix.$f,'size'=>filesize($p),'mtime'=>filemtime($p)); } }
  };
  $scan($ROOT,'');
  if(is_dir($ROOT.'/icons')) $scan($ROOT.'/icons','icons/');
  $sw = is_file($ROOT.'/sw.js') ? file_get_contents($ROOT.'/sw.js') : '';
  preg_match('/eden-os-v(\d+)/',$sw,$m); $cache = isset($m[1])?intval($m[1]):0;
  out(array('ok'=>true,'version'=>$ver,'cache'=>$cache,'files'=>$files,'php'=>PHP_VERSION,'zip'=>class_exists('ZipArchive')));
}

// ---------- edit version.json ----------
if($action==='set_version'){
  owner_or_die();
  $ver = jload($ROOT.'/version.json'); if(!is_array($ver)) $ver=array();
  if(isset($in['version'])) $ver['version']=trim($in['version']);
  if(isset($in['canal']))   $ver['canal']=trim($in['canal']);
  if(isset($in['date']))    $ver['date']=trim($in['date']);
  if(isset($in['notes']) && is_array($in['notes'])) $ver['notes']=$in['notes'];
  $t=$ROOT.'/version.json.tmp'; file_put_contents($t,json_encode($ver,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); rename($t,$ROOT.'/version.json');
  out(array('ok'=>true,'version'=>$ver));
}

// ---------- bump cache SW: forteaza update pe toate dispozitivele ----------
if($action==='bump_cache'){
  owner_or_die();
  $swF=$ROOT.'/sw.js'; $sw=file_get_contents($swF);
  $sw=preg_replace_callback('/eden-os-v(\d+)/',function($m){ return 'eden-os-v'.(intval($m[1])+1); },$sw,1);
  file_put_contents($swF,$sw);
  preg_match('/eden-os-v(\d+)/',$sw,$m);
  out(array('ok'=>true,'cache'=>intval($m[1])));
}

// ---------- backup: salveaza copie a fisierelor curente ----------
function do_backup($ROOT,$bkDir){
  if(!is_dir($bkDir)) @mkdir($bkDir,0755,true);
  $stamp=date('Ymd_His');
  foreach(array('index.html','app.html','sw.js','version.json','manifest.webmanifest') as $f){
    if(is_file($ROOT.'/'.$f)) @copy($ROOT.'/'.$f,$bkDir.'/'.$stamp.'__'.$f);
  }
  return $stamp;
}

// ---------- publish un singur fisier (multipart) ----------
if($action==='publish_file'){
  owner_or_die();
  if(empty($_FILES['file'])) fail(400,'no_file');
  if($_FILES['file']['error']!==UPLOAD_ERR_OK) fail(400,'upload_esuat_'.$_FILES['file']['error'].' (limita '.ini_get('upload_max_filesize').')');
  $target = isset($_POST['target']) ? $_POST['target'] : $_FILES['file']['name'];
  $t = allowed_target($target); if($t===false) fail(400,'not_allowed');
  $stamp = do_backup($ROOT,$bkDir);
  $dest = $ROOT.'/'.$t;
  if(strpos($t,'icons/')===0 && !is_dir($ROOT.'/icons')) @mkdir($ROOT.'/icons',0755,true);
  if(!@move_uploaded_file($_FILES['file']['tmp_name'],$dest)) fail(500,'write_failed');
  out(array('ok'=>true,'written'=>$t,'backup'=>$stamp));
}

// ---------- publish bundle .zip (multipart) ----------
if($action==='publish_zip'){
  owner_or_die();
  if(!class_exists('ZipArchive')) fail(400,'no_zip_support');
  if(empty($_FILES['file'])) fail(400,'no_file');
  if($_FILES['file']['error']!==UPLOAD_ERR_OK) fail(400,'upload_esuat_'.$_FILES['file']['error'].' (limita '.ini_get('upload_max_filesize').')');
  $za=new ZipArchive();
  if($za->open($_FILES['file']['tmp_name'])!==true) fail(400,'bad_zip');
  $stamp=do_backup($ROOT,$bkDir);
  list($written,$skipped,$errors)=apply_zip($za,$ROOT);
  $za->close();
  out(array('ok'=>count($errors)===0,'written'=>$written,'skipped'=>$skipped,'errors'=>$errors,'backup'=>$stamp));
}

// ---------- lista backup-uri ----------
if($action==='list_backups'){
  owner_or_die();
  $list=array();
  if(is_dir($bkDir)){ foreach(scandir($bkDir) as $f){ if($f==='.'||$f==='..')continue; $list[]=array('name'=>$f,'size'=>filesize($bkDir.'/'.$f),'mtime'=>filemtime($bkDir.'/'.$f)); } }
  out(array('ok'=>true,'backups'=>$list));
}

// ---------- EDEN OS Update (firmware + aplicatii, ca Windows Update) ----------
if($action==='system_get'){
  owner_or_die();
  $sys=jload($ROOT.'/system.json');
  out(array('ok'=>true,'system'=>$sys));
}

if($action==='system_set'){ // owner editeaza firmware / channel_url / versiuni aplicatii
  owner_or_die();
  $sys=jload($ROOT.'/system.json'); if(!is_array($sys)) $sys=array();
  if(isset($in['firmware'])) $sys['firmware']=trim($in['firmware']);
  if(isset($in['channel_url'])) $sys['channel_url']=trim($in['channel_url']);
  if(isset($in['channel'])) $sys['channel']=trim($in['channel']);
  if(isset($in['apps']) && is_array($in['apps'])) $sys['apps']=$in['apps'];
  jsave2($ROOT.'/system.json',$sys);
  out(array('ok'=>true,'system'=>$sys));
}

if($action==='system_check'){ // verifica automat canalul online (ca Windows Update)
  owner_or_die();
  $sys=jload($ROOT.'/system.json');
  $url=isset($sys['channel_url'])?trim($sys['channel_url']):'';
  if($url===''){ out(array('ok'=>true,'manual'=>true,'system'=>$sys)); }
  $code=0; $raw=http_get_raw($url,$code);
  if($code<200||$code>=300||!$raw){ out(array('ok'=>false,'error'=>'channel_unreachable','http'=>$code)); }
  $rem=json_decode($raw,true);
  if(!is_array($rem)){ out(array('ok'=>false,'error'=>'bad_manifest')); }
  $updates=array();
  if(isset($rem['firmware']) && ver_gt($rem['firmware'], isset($sys['firmware'])?$sys['firmware']:'0')){
    $updates[]=array('type'=>'firmware','id'=>'firmware','name'=>'Firmware '.(isset($sys['os_name'])?$sys['os_name']:'EDEN OS'),'current'=>isset($sys['firmware'])?$sys['firmware']:'—','latest'=>$rem['firmware']);
  }
  $localApps=array(); foreach((isset($sys['apps'])?$sys['apps']:array()) as $a){ $localApps[$a['id']]=$a; }
  foreach((isset($rem['apps'])?$rem['apps']:array()) as $ra){
    $cur=isset($localApps[$ra['id']]['version'])?$localApps[$ra['id']]['version']:'0';
    if(ver_gt($ra['version'],$cur)){
      $nm=isset($localApps[$ra['id']]['name'])?$localApps[$ra['id']]['name']:$ra['id'];
      $updates[]=array('type'=>'app','id'=>$ra['id'],'name'=>$nm,'current'=>(isset($localApps[$ra['id']])?$cur:'neinstalat'),'latest'=>$ra['version']);
    }
  }
  out(array('ok'=>true,'uptodate'=>count($updates)===0,'updates'=>$updates,'package_url'=>isset($rem['package_url'])?$rem['package_url']:'','remote'=>array('firmware'=>isset($rem['firmware'])?$rem['firmware']:'','build'=>isset($rem['build'])?$rem['build']:'','notes'=>isset($rem['notes'])?$rem['notes']:array()),'system'=>$sys));
}

if($action==='apply_update'){ // descarca pachetul de pe canal si il aplica SINGUR (fara cPanel)
  owner_or_die();
  if(!class_exists('ZipArchive')) fail(400,'no_zip_support');
  $sys=jload($ROOT.'/system.json');
  $pkg=isset($in['package_url'])?trim($in['package_url']):'';
  if($pkg===''){ // ia din manifest daca nu e dat explicit
    $url=isset($sys['channel_url'])?trim($sys['channel_url']):''; if($url==='') fail(400,'no_channel');
    $code=0; $raw=http_get_raw($url,$code); $rem=json_decode($raw,true);
    $pkg=isset($rem['package_url'])?$rem['package_url']:'';
  }
  if($pkg==='') fail(400,'no_package');
  if(!preg_match('#^https://#i',$pkg)) fail(400,'insecure_url'); // doar HTTPS
  $code=0; $data=http_get_raw($pkg,$code);
  if($code<200||$code>=300||!$data) fail(502,'download_failed');
  $tmp=@tempnam(sys_get_temp_dir(),'edenupd');
  if(!$tmp || @file_put_contents($tmp,$data)!==strlen($data)){ if($tmp) @unlink($tmp); $tmp=$GLOBALS['dir'].'/.edenupd-'.bin2hex(random_bytes(4)).'.zip'; if(@file_put_contents($tmp,$data)!==strlen($data)){ @unlink($tmp); fail(500,'nu_pot_salva_pachetul'); } }
  $za=new ZipArchive();
  if($za->open($tmp)!==true){ @unlink($tmp); fail(400,'bad_zip'); }
  $stamp=do_backup($ROOT,$bkDir);
  list($written,$skipped,$errors)=apply_zip($za,$ROOT);
  $za->close(); @unlink($tmp);
  // actualizeaza system.json din manifest (daca a fost dat prin canal)
  if(!empty($in['bump']) && is_array($in['bump'])){ $sys2=jload($ROOT.'/system.json'); foreach($in['bump'] as $k=>$v){ $sys2[$k]=$v; } jsave2($ROOT.'/system.json',$sys2); }
  out(array('ok'=>count($errors)===0,'written'=>$written,'skipped'=>$skipped,'errors'=>$errors,'backup'=>$stamp));
}

// ---------- diagnostic: de ce nu se pot scrie fisierele (doar citire) ----------
if($action==='diag'){
  owner_or_die();
  $f=array();
  foreach(array('app.html','verificator.html','sw.js','version.json','system.json','admin.php') as $n){ $p=$ROOT.'/'.$n; $f[]=array('file'=>$n,'exista'=>is_file($p),'scriere'=>is_file($p)&&is_writable($p),'proprietar'=>is_file($p)?@fileowner($p):null,'drepturi'=>is_file($p)?substr(sprintf('%o',@fileperms($p)),-4):null); }
  out(array('ok'=>true,'php'=>PHP_VERSION,'zip'=>class_exists('ZipArchive'),'curl'=>function_exists('curl_init'),'proces_uid'=>function_exists('posix_geteuid')?posix_geteuid():getmyuid(),'dosar'=>array('scriere'=>is_writable($ROOT),'proprietar'=>@fileowner($ROOT),'drepturi'=>substr(sprintf('%o',@fileperms($ROOT)),-4)),'temp_scriere'=>is_writable(sys_get_temp_dir()),'fisiere'=>$f));
}

fail(400,'unknown_action');
