const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const ev = {name:'SW38 — Roquetas de Mar', venue:'Las Salinas', start:'2026-09-03', end:'2026-09-07', currency:'€', bars:[
    {id:'b1',name:'Bar Stage 1 Main',type:'REGULAR'},{id:'b2',name:'Bar Central Stânga',type:'REGULAR'},
    {id:'b3',name:'Bar Central Dreapta',type:'REGULAR'},{id:'b4',name:'Backstage VIP Stage 1',type:'VIP'},
    {id:'b5',name:'Backstage VIP Stage 2',type:'VIP'}]};
  const state = {magazie:{ts:Date.now(),docs:{'events/sw38':ev}}};
  const b = await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const page = await b.newPage({viewport:{width:1240,height:900}});
  page.on('pageerror',e=>console.log('PAGEERROR:',e.message));
  page.on('console',m=>{if(m.type()==='error' && !/ERR_TUNNEL|Failed to load resource/.test(m.text()))console.log('CONSOLE:',m.text())});
  await page.addInitScript(({state})=>{ localStorage.setItem('eden_session','tok'); localStorage.setItem('uh_ecosistem_v1', JSON.stringify(state)); localStorage.setItem('mg:ev','sw38'); localStorage.setItem('mg:me','Vali'); },{state});
  await page.goto('http://127.0.0.1:8901/magazie.html',{waitUntil:'domcontentloaded'});
  await page.waitForTimeout(1800);
  await page.click('[data-act="importCat"]'); await page.waitForTimeout(600);
  await page.click('[data-act="importRec"]'); await page.waitForTimeout(900);
  await page.click('[data-route="dash"]'); await page.waitForTimeout(500);
  await page.screenshot({path:'r1.png'});
  await page.click('[data-route="prod"]'); await page.waitForTimeout(500);
  await page.screenshot({path:'r2.png'});
  await page.click('[data-route="stock"]'); await page.waitForTimeout(400);
  await page.click('.chip[data-loc="__MAG__"]'); await page.waitForTimeout(500);
  await page.screenshot({path:'r3.png'});
  await b.close();
})();
