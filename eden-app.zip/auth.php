<?php
// EDEN OS — Faza 2.5 auth (beta, file-based).
// Metode: parola (default) + Google/Facebook OAuth + WhatsApp OTP + TOTP (Google Authenticator).
// Providerii externi sunt OPTIONALI: apar doar daca sunt configurati in data/auth_config.json.
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$dir = __DIR__ . '/data';
if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
$ht = $dir . '/.htaccess';
if (!is_file($ht)) { @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n"); }
$usersF = $dir . '/users.json';
$sessF  = $dir . '/sessions.json';
$cfgF   = $dir . '/auth_config.json';
$stateF = $dir . '/oauth_state.json';
$waF    = $dir . '/wa_codes.json';
$pendF  = $dir . '/login_pending.json';
$masterF= $dir . '/master.json';

function jload($f){ return is_file($f) ? json_decode(file_get_contents($f), true) : array(); }
function jsave($f,$d){ $t=$f.'.tmp'; file_put_contents($t, json_encode($d), LOCK_EX); rename($t,$f); }
function out($d){ echo json_encode($d); exit; }
function fail($code,$msg){ http_response_code($code); echo json_encode(array('error'=>$msg)); exit; }
function newtok(){ return bin2hex(random_bytes(24)); }
function cfg(){ global $cfgF; $c=jload($cfgF); return is_array($c)?$c:array(); }
function cfgv($c,$a,$b){ return isset($c[$a][$b]) ? trim($c[$a][$b]) : ''; }

function sess_get(){ global $sessF; $tok = isset($_SERVER['HTTP_X_EDEN_SESSION']) ? $_SERVER['HTTP_X_EDEN_SESSION'] : ''; if(!$tok) return null; $s=jload($sessF); if(!isset($s[$tok])) return null; if($s[$tok]['exp'] < time()){ unset($s[$tok]); jsave($sessF,$s); return null;} return $s[$tok]; }
function issue_session($u){ global $sessF; $tok=newtok(); $s=jload($sessF); $s[$tok]=array('user'=>$u['user'],'role'=>$u['role'],'name'=>$u['name'],'exp'=>time()+2592000); jsave($sessF,$s); return $tok; }
function save_users($list){ global $usersF; jsave($usersF,$list); }
function find_user(&$users,$key,$val){ foreach($users as $i=>$x){ if(isset($x[$key]) && $x[$key]===$val) return $i; } return -1; }

// ---- TOTP (RFC 6238) — pur PHP, compatibil Google Authenticator/Authy ----
function b32enc($bin){ $alph='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $out=''; $bits=''; for($i=0;$i<strlen($bin);$i++){ $bits.=str_pad(decbin(ord($bin[$i])),8,'0',STR_PAD_LEFT); } for($i=0;$i+5<=strlen($bits);$i+=5){ $out.=$alph[bindec(substr($bits,$i,5))]; } $rem=strlen($bits)%5; if($rem){ $out.=$alph[bindec(str_pad(substr($bits,-$rem),5,'0',STR_PAD_RIGHT))]; } return $out; }
function b32dec($b32){ $alph='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $b32=strtoupper(preg_replace('/[^A-Z2-7]/','',$b32)); $bits=''; for($i=0;$i<strlen($b32);$i++){ $v=strpos($alph,$b32[$i]); if($v===false)continue; $bits.=str_pad(decbin($v),5,'0',STR_PAD_LEFT); } $bin=''; for($i=0;$i+8<=strlen($bits);$i+=8){ $bin.=chr(bindec(substr($bits,$i,8))); } return $bin; }
function totp_code($secret_b32,$ts=null,$step=30,$digits=6){ if($ts===null)$ts=time(); $ctr=floor($ts/$step); $bin=pack('N*',0).pack('N*',$ctr); $key=b32dec($secret_b32); $h=hash_hmac('sha1',$bin,$key,true); $off=ord($h[19])&0xf; $val=((ord($h[$off])&0x7f)<<24)|((ord($h[$off+1])&0xff)<<16)|((ord($h[$off+2])&0xff)<<8)|(ord($h[$off+3])&0xff); $code=$val%pow(10,$digits); return str_pad($code,$digits,'0',STR_PAD_LEFT); }
function totp_check($secret_b32,$code,$window=1){ $code=preg_replace('/\s+/','',$code); for($w=-$window;$w<=$window;$w++){ if(hash_equals(totp_code($secret_b32,time()+$w*30),$code)) return true; } return false; }

// ---- Cod master (recuperare / acces peste tot) ----
function master_norm($c){ return strtoupper(preg_replace('/[^A-Za-z0-9]/','',$c)); }
function master_gen(){ $raw=strtoupper(bin2hex(random_bytes(8))); return $raw; } // 16 hex
function master_fmt($raw){ return implode('-', str_split($raw,4)); }        // XXXX-XXXX-XXXX-XXXX
function master_set(){ global $masterF; $raw=master_gen(); jsave($masterF,array('hash'=>password_hash($raw,PASSWORD_DEFAULT),'created'=>time(),'tries'=>0,'lock'=>0)); return master_fmt($raw); }
function master_check($code){ global $masterF; $m=jload($masterF); if(empty($m['hash'])) return false;
  if(!empty($m['lock']) && $m['lock']>time()) return false;
  $ok=password_verify(master_norm($code),$m['hash']);
  if(!$ok){ $m['tries']=(isset($m['tries'])?$m['tries']:0)+1; if($m['tries']>=5){ $m['lock']=time()+900; $m['tries']=0; } jsave($masterF,$m); return false; }
  $m['tries']=0; $m['lock']=0; jsave($masterF,$m); return true;
}

function http_post($url,$fields,$json=false){ $ch=curl_init($url); curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_TIMEOUT=>15,CURLOPT_POSTFIELDS=>$json?json_encode($fields):http_build_query($fields),CURLOPT_HTTPHEADER=>$json?array('Content-Type: application/json'):array())); $r=curl_exec($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch); return array($code,$r); }
function http_get($url,$headers=array()){ $ch=curl_init($url); curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>15,CURLOPT_HTTPHEADER=>$headers)); $r=curl_exec($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch); return array($code,$r); }

$raw = file_get_contents('php://input');
$in = json_decode($raw, true); if(!is_array($in)) $in=array();
$action = isset($in['action']) ? $in['action'] : (isset($_GET['action'])?$_GET['action']:'');
$users = jload($usersF);
$C = cfg();

// ---------- status / providers ----------
if ($action === 'status') { out(array('setup_needed' => (count($users)===0))); }

if ($action === 'providers') {
  out(array('ok'=>true,'providers'=>array(
    'password'=>true,
    'totp'=>true,
    'google'=> (cfgv($C,'google','client_id')!=='' && cfgv($C,'google','client_secret')!==''),
    'facebook'=> (cfgv($C,'facebook','app_id')!=='' && cfgv($C,'facebook','app_secret')!==''),
    'whatsapp'=> (cfgv($C,'whatsapp','token')!=='' && cfgv($C,'whatsapp','phone_number_id')!=='')
  )));
}

// ---------- setup / password login ----------
if ($action === 'setup') {
  if (count($users) > 0) fail(409,'already_setup');
  $u=trim(isset($in['user'])?$in['user']:''); $p=isset($in['pass'])?$in['pass']:''; $n=trim(isset($in['name'])?$in['name']:$u);
  if(strlen($u)<3||strlen($p)<6) fail(400,'weak');
  $nu=array('user'=>$u,'name'=>$n,'role'=>'owner','hash'=>password_hash($p,PASSWORD_DEFAULT),'created'=>time());
  $users[]=$nu; save_users($users);
  $master=master_set(); // genereaza codul master de recuperare o singura data
  out(array('ok'=>true,'token'=>issue_session($nu),'user'=>$u,'role'=>'owner','name'=>$n,'master_code'=>$master));
}

if ($action === 'login') {
  $u=trim(isset($in['user'])?$in['user']:''); $p=isset($in['pass'])?$in['pass']:'';
  $i=find_user($users,'user',$u);
  if($i<0 || !password_verify($p,$users[$i]['hash'])) fail(401,'invalid_credentials');
  if(!empty($users[$i]['totp_enabled'])){
    // pas 2: cere codul TOTP
    $tmp=newtok(); $pend=jload($pendF); $pend[$tmp]=array('user'=>$u,'exp'=>time()+300); jsave($pendF,$pend);
    out(array('ok'=>false,'totp_required'=>true,'tmp'=>$tmp));
  }
  out(array('ok'=>true,'token'=>issue_session($users[$i]),'user'=>$u,'role'=>$users[$i]['role'],'name'=>$users[$i]['name']));
}

if ($action === 'login_totp') {
  $tmp=isset($in['tmp'])?$in['tmp']:''; $code=isset($in['code'])?$in['code']:'';
  $pend=jload($pendF); if(!isset($pend[$tmp])||$pend[$tmp]['exp']<time()) fail(401,'expired');
  $u=$pend[$tmp]['user']; $i=find_user($users,'user',$u);
  if($i<0||empty($users[$i]['totp_secret'])||!totp_check($users[$i]['totp_secret'],$code)) fail(401,'bad_code');
  unset($pend[$tmp]); jsave($pendF,$pend);
  out(array('ok'=>true,'token'=>issue_session($users[$i]),'user'=>$u,'role'=>$users[$i]['role'],'name'=>$users[$i]['name']));
}

if ($action === 'me') {
  $me=sess_get(); if(!$me) fail(401,'no_session');
  $i=find_user($users,'user',$me['user']); $x=$i>=0?$users[$i]:array();
  out(array('ok'=>true,'user'=>$me['user'],'role'=>$me['role'],'name'=>$me['name'],
    'totp_enabled'=>!empty($x['totp_enabled']),
    'linked'=>isset($x['providers'])?array_keys($x['providers']):array(),
    'email'=>isset($x['email'])?$x['email']:'','phone'=>isset($x['phone'])?$x['phone']:''));
}

if ($action === 'logout') { $tok=isset($_SERVER['HTTP_X_EDEN_SESSION'])?$_SERVER['HTTP_X_EDEN_SESSION']:''; if($tok){ $s=jload($sessF); if(isset($s[$tok])){ unset($s[$tok]); jsave($sessF,$s);} } out(array('ok'=>true)); }

// ---------- TOTP enrol (Google Authenticator) ----------
if ($action === 'totp_setup') {
  $me=sess_get(); if(!$me) fail(401,'no_session');
  $secret=b32enc(random_bytes(20));
  $i=find_user($users,'user',$me['user']); if($i<0) fail(404,'no_user');
  $users[$i]['totp_pending']=$secret; save_users($users);
  $label=rawurlencode('EDEN · '.$me['user']); $issuer=rawurlencode('Universul HoReCa');
  $otpauth="otpauth://totp/$label?secret=$secret&issuer=$issuer&digits=6&period=30";
  out(array('ok'=>true,'secret'=>$secret,'otpauth'=>$otpauth));
}
if ($action === 'totp_enable') {
  $me=sess_get(); if(!$me) fail(401,'no_session'); $code=isset($in['code'])?$in['code']:'';
  $i=find_user($users,'user',$me['user']); if($i<0||empty($users[$i]['totp_pending'])) fail(400,'no_pending');
  if(!totp_check($users[$i]['totp_pending'],$code)) fail(401,'bad_code');
  $users[$i]['totp_secret']=$users[$i]['totp_pending']; $users[$i]['totp_enabled']=true; unset($users[$i]['totp_pending']); save_users($users);
  out(array('ok'=>true));
}
if ($action === 'totp_disable') {
  $me=sess_get(); if(!$me) fail(401,'no_session'); $code=isset($in['code'])?$in['code']:'';
  $i=find_user($users,'user',$me['user']); if($i<0||empty($users[$i]['totp_secret'])) fail(400,'not_enabled');
  if(!totp_check($users[$i]['totp_secret'],$code)) fail(401,'bad_code');
  unset($users[$i]['totp_secret']); $users[$i]['totp_enabled']=false; save_users($users);
  out(array('ok'=>true));
}

// ---------- OAuth (Google / Facebook) ----------
if ($action === 'oauth_start') {
  $prov=isset($_GET['provider'])?$_GET['provider']:(isset($in['provider'])?$in['provider']:'');
  $base=rtrim(cfgv($C,'app','base_url'),'/'); if($base==='') $base=(isset($_SERVER['HTTPS'])?'https':'http').'://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['REQUEST_URI']);
  $redirect=$base.'/auth.php?action=oauth_callback&provider='.$prov;
  $state=newtok(); $st=jload($stateF); $st[$state]=array('prov'=>$prov,'exp'=>time()+600); jsave($stateF,$st);
  if($prov==='google'){ $cid=cfgv($C,'google','client_id'); if($cid==='') fail(400,'not_configured');
    $url='https://accounts.google.com/o/oauth2/v2/auth?'.http_build_query(array('client_id'=>$cid,'redirect_uri'=>$redirect,'response_type'=>'code','scope'=>'openid email profile','state'=>$state,'access_type'=>'online','prompt'=>'select_account'));
    out(array('ok'=>true,'url'=>$url));
  }
  if($prov==='facebook'){ $aid=cfgv($C,'facebook','app_id'); if($aid==='') fail(400,'not_configured');
    $url='https://www.facebook.com/v19.0/dialog/oauth?'.http_build_query(array('client_id'=>$aid,'redirect_uri'=>$redirect,'response_type'=>'code','scope'=>'email public_profile','state'=>$state));
    out(array('ok'=>true,'url'=>$url));
  }
  fail(400,'unknown_provider');
}

if ($action === 'oauth_callback') {
  header('Content-Type: text/html; charset=utf-8');
  $prov=isset($_GET['provider'])?$_GET['provider']:''; $code=isset($_GET['code'])?$_GET['code']:''; $state=isset($_GET['state'])?$_GET['state']:'';
  $st=jload($stateF); if(!isset($st[$state])||$st[$state]['exp']<time()){ echo oauth_html(null,'stare invalida'); exit; } unset($st[$state]); jsave($stateF,$st);
  $base=rtrim(cfgv($C,'app','base_url'),'/'); if($base==='') $base=(isset($_SERVER['HTTPS'])?'https':'http').'://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['REQUEST_URI']);
  $redirect=$base.'/auth.php?action=oauth_callback&provider='.$prov;
  $email=''; $name=''; $pid='';
  if($prov==='google'){
    list($hc,$tr)=http_post('https://oauth2.googleapis.com/token',array('code'=>$code,'client_id'=>cfgv($C,'google','client_id'),'client_secret'=>cfgv($C,'google','client_secret'),'redirect_uri'=>$redirect,'grant_type'=>'authorization_code'));
    $tj=json_decode($tr,true); if(empty($tj['access_token'])){ echo oauth_html(null,'schimb token esuat'); exit; }
    list($uc,$ur)=http_get('https://openidconnect.googleapis.com/v1/userinfo',array('Authorization: Bearer '.$tj['access_token']));
    $uj=json_decode($ur,true); $email=isset($uj['email'])?strtolower($uj['email']):''; $name=isset($uj['name'])?$uj['name']:$email; $pid=isset($uj['sub'])?$uj['sub']:'';
  } elseif($prov==='facebook'){
    list($hc,$tr)=http_get('https://graph.facebook.com/v19.0/oauth/access_token?'.http_build_query(array('client_id'=>cfgv($C,'facebook','app_id'),'client_secret'=>cfgv($C,'facebook','app_secret'),'redirect_uri'=>$redirect,'code'=>$code)));
    $tj=json_decode($tr,true); if(empty($tj['access_token'])){ echo oauth_html(null,'schimb token esuat'); exit; }
    list($uc,$ur)=http_get('https://graph.facebook.com/me?'.http_build_query(array('fields'=>'id,name,email','access_token'=>$tj['access_token'])));
    $uj=json_decode($ur,true); $email=isset($uj['email'])?strtolower($uj['email']):''; $name=isset($uj['name'])?$uj['name']:''; $pid=isset($uj['id'])?$uj['id']:'';
  } else { echo oauth_html(null,'provider necunoscut'); exit; }
  if($email===''){ echo oauth_html(null,'email indisponibil de la provider'); exit; }
  $i=find_user($users,'email',$email);
  if($i<0){ $uname='g_'.substr(md5($email),0,10); $role=(count($users)===0)?'owner':'staff';
    $nu=array('user'=>$uname,'name'=>$name?:$email,'role'=>$role,'email'=>$email,'hash'=>password_hash(newtok(),PASSWORD_DEFAULT),'providers'=>array($prov=>$pid),'created'=>time());
    $users[]=$nu; save_users($users); $i=count($users)-1;
  } else { $users[$i]['providers'][$prov]=$pid; if(empty($users[$i]['name'])&&$name)$users[$i]['name']=$name; save_users($users); }
  echo oauth_html(issue_session($users[$i]),null); exit;
}
function oauth_html($tok,$err){
  if($tok){ $j=json_encode($tok); return '<!doctype html><meta charset="utf-8"><body style="background:#000;color:#F2F2F2;font:14px Inter,Arial;text-align:center;padding-top:40px">Autentificat. Redirect…<script>try{localStorage.setItem("eden_session",'.$j.');}catch(e){}location.replace("index.html");</script></body>'; }
  return '<!doctype html><meta charset="utf-8"><body style="background:#000;color:#ff9a9a;font:14px Inter,Arial;text-align:center;padding-top:40px">Autentificare esuata: '.htmlspecialchars($err).'<br><br><a style="color:#FF6600" href="index.html">Inapoi</a></body>';
}

// ---------- WhatsApp OTP ----------
if ($action === 'wa_request') {
  $phone=preg_replace('/[^0-9]/','',isset($in['phone'])?$in['phone']:''); if(strlen($phone)<8) fail(400,'bad_phone');
  if(cfgv($C,'whatsapp','token')===''||cfgv($C,'whatsapp','phone_number_id')==='') fail(400,'not_configured');
  $code=str_pad(random_int(0,999999),6,'0',STR_PAD_LEFT);
  $wa=jload($waF); $wa[$phone]=array('hash'=>password_hash($code,PASSWORD_DEFAULT),'exp'=>time()+300,'tries'=>0); jsave($waF,$wa);
  $pnid=cfgv($C,'whatsapp','phone_number_id'); $tok=cfgv($C,'whatsapp','token');
  $tpl=cfgv($C,'whatsapp','template'); // daca e setat un template aprobat, il folosim; altfel text simplu
  if($tpl!==''){ $payload=array('messaging_product'=>'whatsapp','to'=>$phone,'type'=>'template','template'=>array('name'=>$tpl,'language'=>array('code'=>'ro'),'components'=>array(array('type'=>'body','parameters'=>array(array('type'=>'text','text'=>$code)))))); }
  else { $payload=array('messaging_product'=>'whatsapp','to'=>$phone,'type'=>'text','text'=>array('body'=>'Codul tau EDEN: '.$code.' (valabil 5 min).')); }
  $ch=curl_init('https://graph.facebook.com/v19.0/'.$pnid.'/messages');
  curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_TIMEOUT=>15,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>array('Authorization: Bearer '.$tok,'Content-Type: application/json')));
  $r=curl_exec($ch); $hc=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  if($hc<200||$hc>=300){ out(array('ok'=>false,'error'=>'send_failed','detail'=>json_decode($r,true))); }
  out(array('ok'=>true));
}
if ($action === 'wa_verify') {
  $phone=preg_replace('/[^0-9]/','',isset($in['phone'])?$in['phone']:''); $code=isset($in['code'])?$in['code']:'';
  $wa=jload($waF); if(!isset($wa[$phone])||$wa[$phone]['exp']<time()) fail(401,'expired');
  if($wa[$phone]['tries']>=5){ unset($wa[$phone]); jsave($waF,$wa); fail(429,'too_many'); }
  if(!password_verify($code,$wa[$phone]['hash'])){ $wa[$phone]['tries']++; jsave($waF,$wa); fail(401,'bad_code'); }
  unset($wa[$phone]); jsave($waF,$wa);
  $i=find_user($users,'phone',$phone);
  if($i<0){ $uname='w_'.substr($phone,-8); $role=(count($users)===0)?'owner':'staff';
    $nu=array('user'=>$uname,'name'=>'+' .$phone,'role'=>$role,'phone'=>$phone,'hash'=>password_hash(newtok(),PASSWORD_DEFAULT),'providers'=>array('whatsapp'=>$phone),'created'=>time());
    $users[]=$nu; save_users($users); $i=count($users)-1;
  }
  out(array('ok'=>true,'token'=>issue_session($users[$i]),'user'=>$users[$i]['user'],'role'=>$users[$i]['role'],'name'=>$users[$i]['name']));
}

// ---------- Cod master: status / login / reset ----------
if ($action === 'master_status') { $m=jload($masterF); out(array('ok'=>true,'set'=>!empty($m['hash']))); }

if ($action === 'master_login') {
  $code=isset($in['code'])?$in['code']:'';
  if(!master_check($code)) fail(401,'bad_master');
  // intra ca primul owner (acces peste tot)
  $i=-1; foreach($users as $k=>$x){ if($x['role']==='owner'){ $i=$k; break; } }
  if($i<0){ if(count($users)===0) fail(409,'no_users'); $i=0; }
  out(array('ok'=>true,'token'=>issue_session($users[$i]),'user'=>$users[$i]['user'],'role'=>$users[$i]['role'],'name'=>$users[$i]['name'],'master'=>true));
}

if ($action === 'master_reset') { // reseteaza parola unui cont folosind codul master
  $code=isset($in['code'])?$in['code']:''; $u=trim(isset($in['user'])?$in['user']:''); $p=isset($in['pass'])?$in['pass']:'';
  if(!master_check($code)) fail(401,'bad_master');
  if(strlen($p)<6) fail(400,'weak');
  $i=find_user($users,'user',$u); if($i<0) fail(404,'no_user');
  $users[$i]['hash']=password_hash($p,PASSWORD_DEFAULT);
  $users[$i]['totp_enabled']=false; unset($users[$i]['totp_secret']); unset($users[$i]['totp_pending']); // deblocheaza complet
  save_users($users); out(array('ok'=>true));
}

// ---------- admin (owner) ----------
if ($action === 'set_master') { // owner regenereaza codul master
  $me=sess_get(); if(!$me || $me['role']!=='owner') fail(403,'forbidden');
  out(array('ok'=>true,'master_code'=>master_set()));
}

if ($action === 'reset_password') { // owner reseteaza parola oricui
  $me=sess_get(); if(!$me || $me['role']!=='owner') fail(403,'forbidden');
  $u=trim(isset($in['user'])?$in['user']:''); $p=isset($in['pass'])?$in['pass']:'';
  if(strlen($p)<6) fail(400,'weak');
  $i=find_user($users,'user',$u); if($i<0) fail(404,'no_user');
  $users[$i]['hash']=password_hash($p,PASSWORD_DEFAULT);
  if(!empty($in['clear_2fa'])){ $users[$i]['totp_enabled']=false; unset($users[$i]['totp_secret']); unset($users[$i]['totp_pending']); }
  save_users($users); out(array('ok'=>true));
}

if ($action === 'create_user') {
  $me=sess_get(); if(!$me || $me['role']!=='owner') fail(403,'forbidden');
  $u=trim(isset($in['user'])?$in['user']:''); $p=isset($in['pass'])?$in['pass']:''; $n=trim(isset($in['name'])?$in['name']:$u); $r=isset($in['role'])?$in['role']:'staff';
  if(strlen($u)<3||strlen($p)<6) fail(400,'weak');
  if(find_user($users,'user',$u)>=0) fail(409,'exists');
  if($r!=='owner'&&$r!=='manager') $r='staff';
  $users[]=array('user'=>$u,'name'=>$n,'role'=>$r,'hash'=>password_hash($p,PASSWORD_DEFAULT),'created'=>time());
  save_users($users); out(array('ok'=>true,'user'=>$u,'role'=>$r,'name'=>$n));
}
if ($action === 'list_users') {
  $me=sess_get(); if(!$me || $me['role']!=='owner') fail(403,'forbidden');
  $list=array(); foreach($users as $x){ $list[]=array('user'=>$x['user'],'name'=>$x['name'],'role'=>$x['role'],'totp'=>!empty($x['totp_enabled']),'linked'=>isset($x['providers'])?array_keys($x['providers']):array()); }
  out(array('ok'=>true,'users'=>$list));
}

fail(400,'unknown_action');
