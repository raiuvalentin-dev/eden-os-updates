<?php
// EDEN OS — sync backend (beta, file-based). Auth reala = Faza 2.5.
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
$TOKEN = 'EDEN-uh-2026-06cc58b481f807b4c1';
$dir = __DIR__ . '/data';
$file = $dir . '/state.json';
if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
$ht = $dir . '/.htaccess';
if (!is_file($ht)) { @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n"); }
$tok = isset($_SERVER['HTTP_X_EDEN_TOKEN']) ? $_SERVER['HTTP_X_EDEN_TOKEN'] : (isset($_GET['t']) ? $_GET['t'] : '');
if (!hash_equals($TOKEN, (string)$tok)) { http_response_code(401); echo json_encode(array('error' => 'unauthorized')); exit; }
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'GET') {
  if (is_file($file)) { echo file_get_contents($file); }
  else { echo json_encode(array('ts' => 0, 'state' => new stdClass())); }
  exit;
}
if ($method === 'POST') {
  $raw = file_get_contents('php://input');
  if (strlen($raw) > 8000000) { http_response_code(413); echo json_encode(array('error' => 'too_large')); exit; }
  $in = json_decode($raw, true);
  if (!is_array($in) || !array_key_exists('state', $in)) { http_response_code(400); echo json_encode(array('error' => 'bad_request')); exit; }
  $ts = isset($in['ts']) ? intval($in['ts']) : 0;
  $cur = is_file($file) ? json_decode(file_get_contents($file), true) : array('ts' => 0);
  $curTs = (is_array($cur) && isset($cur['ts'])) ? intval($cur['ts']) : 0;
  if ($ts >= $curTs) {
    $out = json_encode(array('ts' => $ts, 'state' => $in['state']));
    $tmp = $file . '.tmp';
    file_put_contents($tmp, $out, LOCK_EX);
    rename($tmp, $file);
    echo json_encode(array('ok' => true, 'ts' => $ts));
  } else {
    echo json_encode(array('ok' => false, 'conflict' => true, 'ts' => $curTs));
  }
  exit;
}
http_response_code(405);
echo json_encode(array('error' => 'method_not_allowed'));
