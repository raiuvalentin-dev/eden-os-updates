<?php
// EDEN OS — iEvent: evenimente, sarcini, necesar, documente, echipă.
// Acces cu sesiunea EDEN (login din index.html). Rolurile iEvent: management / angajat.
// Owner-ul EDEN e mereu management. Invitațiile prin link creează cereri; contul se face doar după aprobarea managementului.
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

$dir  = __DIR__ . '/data';
$idir = $dir . '/ievent';
if (!is_dir($idir)) { @mkdir($idir, 0755, true); }
if (!is_file($dir . '/.htaccess')) { @file_put_contents($dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n"); }
$dbF    = $idir . '/db.json';
$usersF = $dir . '/users.json';
$sessF  = $dir . '/sessions.json';

function jload($f){ if (!is_file($f)) return array(); $d = json_decode(file_get_contents($f), true); return is_array($d) ? $d : array(); }
function jsave($f, $d){ $j = json_encode($d, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); $t = $f . '.tmp' . bin2hex(random_bytes(3));
  if ($j === false || $j === '' || @file_put_contents($t, $j, LOCK_EX) !== strlen($j)) { @unlink($t); db_close(); fail(500, 'write_failed'); }   // nu înlocuim niciodată fișierul cu ceva gol
  rename($t, $f); }
function str_in($v){ return is_string($v) ? $v : ''; }
function out($d){ echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }
function fail($c, $m){ http_response_code($c); out(array('error' => $m)); }
function sess(){ global $sessF; $tok = isset($_SERVER['HTTP_X_EDEN_SESSION']) ? $_SERVER['HTTP_X_EDEN_SESSION'] : ''; if (!$tok) return null; $s = jload($sessF); if (!isset($s[$tok]) || $s[$tok]['exp'] < time()) return null; return $s[$tok]; }
function newid($p){ return $p . '-' . bin2hex(random_bytes(6)); }
function u_len($s){ return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen(utf8_decode($s)); }
function u_sub($s,$a,$b){ if (function_exists('mb_substr')) return mb_substr($s, $a, $b, 'UTF-8'); return preg_match('/^.{0,' . intval($b) . '}/us', $s, $m) ? $m[0] : ''; }
function clean_id($v){ return (is_string($v) && preg_match('/^[A-Za-z0-9_.:-]{1,80}$/', $v)) ? $v : null; }

// ---- baza de date (un fișier JSON, cu lacăt) ----
$LOCK = null;
function db_open($shared = false){ global $LOCK, $idir, $dbF; $LOCK = fopen($idir . '/.lock', 'c'); flock($LOCK, $shared ? LOCK_SH : LOCK_EX);
  $db = jload($dbF);
  foreach (array('events','tasks','items','modules','versions','members','requests','invites','pending') as $k) { if (!isset($db[$k]) || !is_array($db[$k])) $db[$k] = array(); }
  if (!isset($db['notifs']) || !is_array($db['notifs'])) $db['notifs'] = array();
  if (!isset($db['rev'])) $db['rev'] = 0;
  return $db; }
function db_save($db){ global $dbF; $db['rev'] = intval($db['rev']) + 1; jsave($dbF, $db); return $db; }
function db_close(){ global $LOCK; if ($LOCK) { flock($LOCK, LOCK_UN); fclose($LOCK); $LOCK = null; } }
function done($db, $extra = array()){ $db = db_save($db); db_close(); out(array_merge(array('ok' => true, 'rev' => $db['rev']), $extra)); }

function role_of($me, $db){ if (!$me) return null; if ($me['role'] === 'owner') return 'management'; $u = $me['user'];
  return isset($db['members'][$u]['role']) ? $db['members'][$u]['role'] : null; }
function user_names(){ global $usersF; $m = array(); foreach (jload($usersF) as $x) { if (isset($x['user'])) $m[$x['user']] = array('name' => isset($x['name']) ? $x['name'] : $x['user'], 'eden' => isset($x['role']) ? $x['role'] : 'staff'); } return $m; }
function add_notif(&$db, $text, $by, $byName, $event){ $db['notifs'][] = array('id' => newid('n'), 'text' => u_sub($text, 0, 400), 'at' => round(microtime(true) * 1000), 'by' => $by, 'byName' => $byName, 'event' => $event);
  if (count($db['notifs']) > 200) $db['notifs'] = array_slice($db['notifs'], -200); }
function safe_doc($d){ if (!is_array($d)) return null; $j = json_encode($d); if ($j === false || strlen($j) > 60000) return null; return $d; }

$in = array();
if ($_SERVER['REQUEST_METHOD'] === 'POST') { $raw = file_get_contents('php://input'); if (strlen($raw) > 3000000) fail(413, 'too_large'); $in = json_decode($raw, true); if (!is_array($in)) $in = array(); }
$action = isset($_GET['action']) ? $_GET['action'] : (isset($in['action']) ? $in['action'] : '');
$me = sess();

// ===================== fără sesiune: invitații =====================
if ($action === 'invite_info') {
  $tok = str_in(isset($_GET['t']) ? $_GET['t'] : ''); $db = db_open(true); db_close();
  if (!$tok || !isset($db['invites'][$tok]) || $db['invites'][$tok]['exp'] < time()) fail(404, 'invite_invalid');
  out(array('ok' => true, 'role' => $db['invites'][$tok]['role']));
}
if ($action === 'join') {
  $tok = str_in(isset($in['t']) ? $in['t'] : ''); $name = trim(str_in(isset($in['name']) ? $in['name'] : '')); $user = trim(str_in(isset($in['user']) ? $in['user'] : '')); $pass = str_in(isset($in['pass']) ? $in['pass'] : '');
  if (u_len($name) < 2 || u_len($name) > 80) fail(400, 'name');
  if (!preg_match('/^[a-z0-9][a-z0-9._-]{2,31}$/', $user) || preg_match('/^[gw]_/', $user)) fail(400, 'user');   // doar litere mici; g_/w_ sunt rezervate de EDEN pentru conturile Google/WhatsApp
  if (strlen($pass) < 8 || strlen($pass) > 200) fail(400, 'pass');
  $db = db_open();
  if (!$tok || !isset($db['invites'][$tok]) || $db['invites'][$tok]['exp'] < time()) { db_close(); fail(404, 'invite_invalid'); }
  $inv = &$db['invites'][$tok];
  if (intval(isset($inv['uses']) ? $inv['uses'] : 0) >= 60) { db_close(); fail(429, 'invite_full'); }
  if (count($db['pending']) >= 80) { db_close(); fail(429, 'too_many_pending'); }
  $inv['uses'] = intval(isset($inv['uses']) ? $inv['uses'] : 0) + 1;   // orice încercare consumă din invitație (fără enumerare nelimitată)
  $taken = isset(user_names()[$user]); foreach ($db['pending'] as $p) { if ($p['user'] === $user) $taken = true; }
  if ($taken) { $db = db_save($db); db_close(); fail(409, 'user_taken'); }
  $id = newid('j');
  $db['pending'][$id] = array('name' => $name, 'user' => $user, 'hash' => password_hash($pass, PASSWORD_DEFAULT), 'role' => $inv['role'], 'at' => time());
  add_notif($db, $name . ' cere cont iEvent ca ' . ($inv['role'] === 'management' ? 'Management' : 'Angajat'), null, $name, null);
  done($db);
}

// ===================== cu sesiune =====================
if (!$me) fail(401, 'no_session');

if ($action === 'poll') { $db = db_open(true); db_close(); out(array('ok' => true, 'rev' => $db['rev'])); }

if ($action === 'state') {
  $db = db_open(true); db_close();
  $role = role_of($me, $db);
  $res = array('ok' => true, 'rev' => $db['rev'], 'me' => array('user' => $me['user'], 'name' => $me['name'], 'eden' => $me['role'], 'role' => $role));
  if (!$role) { $res['request'] = isset($db['requests'][$me['user']]) ? $db['requests'][$me['user']] : null; out($res); }
  $names = user_names(); $people = array();
  foreach ($names as $u => $x) { $r = ($x['eden'] === 'owner') ? 'management' : (isset($db['members'][$u]['role']) ? $db['members'][$u]['role'] : null); if ($r) $people[] = array('user' => $u, 'name' => $x['name'], 'role' => $r, 'owner' => $x['eden'] === 'owner'); }
  foreach (array('events','tasks','items','modules','versions') as $k) $res[$k] = (object)$db[$k];
  $res['notifs'] = array_slice($db['notifs'], -80);
  $res['people'] = $people;
  if ($role === 'management') {
    $req = array(); foreach ($db['requests'] as $u => $r) { $r['user'] = $u; $r['name'] = isset($names[$u]) ? $names[$u]['name'] : $u; $req[] = $r; }
    $pend = array(); foreach ($db['pending'] as $id => $p) { $pend[] = array('id' => $id, 'name' => $p['name'], 'user' => $p['user'], 'role' => $p['role'], 'at' => $p['at']); }
    $inv = array(); foreach ($db['invites'] as $t => $i) { if ($i['exp'] >= time()) $inv[] = array('token' => $t, 'role' => $i['role'], 'exp' => $i['exp'], 'uses' => isset($i['uses']) ? $i['uses'] : 0); }
    $others = array(); foreach ($names as $u => $x) { if ($x['eden'] !== 'owner' && !isset($db['members'][$u])) $others[] = array('user' => $u, 'name' => $x['name']); }
    $res['requests'] = $req; $res['pending'] = $pend; $res['invites'] = $inv; $res['others'] = $others;
  }
  out($res);
}

if ($action === 'request_access') {
  $db = db_open(); if (role_of($me, $db)) { db_close(); out(array('ok' => true, 'already' => true)); }
  $want = (isset($in['role']) && $in['role'] === 'management') ? 'management' : 'angajat';
  if (isset($db['requests'][$me['user']])) { db_close(); out(array('ok' => true, 'pending' => true)); }   // o singură cerere, o singură notificare
  $db['requests'][$me['user']] = array('role' => $want, 'at' => time());
  add_notif($db, $me['name'] . ' cere acces la iEvent ca ' . ($want === 'management' ? 'Management' : 'Angajat'), $me['user'], $me['name'], null);
  done($db);
}

$db = db_open();
$role = role_of($me, $db);
if (!$role) { db_close(); fail(403, 'no_role'); }
$mgmt = $role === 'management';
$COLLS = array('events','tasks','items','modules','versions');

if ($action === 'put') {
  $coll = str_in(isset($in['coll']) ? $in['coll'] : ''); if (!in_array($coll, $COLLS, true)) { db_close(); fail(400, 'coll'); }
  $data = safe_doc(isset($in['data']) ? $in['data'] : null); if ($data === null) { db_close(); fail(400, 'data'); }
  $id = isset($in['id']) ? clean_id($in['id']) : null;
  $exists = $id && isset($db[$coll][$id]);
  if (!$mgmt) {
    // angajatul schimbă doar statusul sarcinilor lui și bifează checklist-ul
    $okTask = $coll === 'tasks' && $exists && isset($db['tasks'][$id]['assigneeUser']) && $db['tasks'][$id]['assigneeUser'] === $me['user'] && array_keys($data) === array('status');
    $okCheck = $coll === 'items' && $exists && isset($db['items'][$id]['module']) && $db['items'][$id]['module'] === 'checklist' && array_keys($data) === array('status');
    if (!$okTask && !$okCheck) { db_close(); fail(403, 'forbidden'); }
  }
  if (!$id) $id = newid(substr($coll, 0, 2));
  unset($data['id']);
  $doc = $exists ? array_merge($db[$coll][$id], $data) : $data;
  foreach ($doc as $k => $v) { if ($v === null) unset($doc[$k]); }
  $doc['updatedAt'] = round(microtime(true) * 1000); $doc['updatedBy'] = $me['user'];
  if (!$exists) { $doc['createdAt'] = isset($doc['createdAt']) ? $doc['createdAt'] : $doc['updatedAt']; $doc['createdBy'] = $me['user']; }
  $db[$coll][$id] = $doc;
  done($db, array('id' => $id));
}
if ($action === 'del') {
  if (!$mgmt) { db_close(); fail(403, 'forbidden'); }
  $coll = str_in(isset($in['coll']) ? $in['coll'] : ''); $id = clean_id(isset($in['id']) ? $in['id'] : '');
  if (!in_array($coll, $COLLS, true) || !$id) { db_close(); fail(400, 'bad'); }
  unset($db[$coll][$id]); done($db);
}
if ($action === 'notify') {
  $text = trim(str_in(isset($in['text']) ? $in['text'] : '')); if ($text === '') { db_close(); fail(400, 'text'); }
  $mine = 0; $since = round(microtime(true) * 1000) - 60000; foreach ($db['notifs'] as $n) { if ($n['by'] === $me['user'] && $n['at'] > $since) $mine++; }
  if ($mine >= 20) { db_close(); fail(429, 'slow_down'); }
  add_notif($db, $text, $me['user'], $me['name'], isset($in['event']) ? clean_id($in['event']) : null);
  done($db);
}

// ---- de aici: doar management ----
if (!$mgmt) { db_close(); fail(403, 'forbidden'); }

if ($action === 'import') {
  $data = isset($in['data']) && is_array($in['data']) ? $in['data'] : array(); $n = 0;
  foreach ($COLLS as $c) { if (!isset($data[$c]) || !is_array($data[$c])) continue;
    foreach ($data[$c] as $id => $doc) { $id = clean_id((string)$id); $doc = safe_doc($doc); if (!$id || $doc === null || isset($db[$c][$id])) continue; $db[$c][$id] = $doc; $n++; } }
  done($db, array('imported' => $n));
}
if ($action === 'bulk') {
  $ops = isset($in['ops']) && is_array($in['ops']) ? $in['ops'] : array(); if (count($ops) > 800) { db_close(); fail(413, 'too_many'); }
  $ids = array(); $now = round(microtime(true) * 1000);
  foreach ($ops as $op) { $c = isset($op['coll']) ? $op['coll'] : ''; $d = safe_doc(isset($op['data']) ? $op['data'] : null);
    if (!in_array($c, $COLLS, true) || $d === null) continue; unset($d['id']);
    $id = newid(substr($c, 0, 2)); $d['createdAt'] = $now; $d['createdBy'] = $me['user']; $db[$c][$id] = $d; $ids[] = $id; }
  done($db, array('ids' => $ids));
}
if ($action === 'set_role') {
  $u = str_in(isset($in['user']) ? $in['user'] : ''); $names = user_names();
  if (!isset($names[$u]) || $names[$u]['eden'] === 'owner') { db_close(); fail(400, 'user'); }
  $r = isset($in['role']) ? $in['role'] : null;
  if ($r === 'management' || $r === 'angajat') $db['members'][$u] = array('role' => $r, 'by' => $me['user'], 'at' => time()); else unset($db['members'][$u]);
  unset($db['requests'][$u]);
  if ($r) add_notif($db, $names[$u]['name'] . ' are acces la iEvent ca ' . ($r === 'management' ? 'Management' : 'Angajat'), $me['user'], $me['name'], null);
  done($db);
}
if ($action === 'reject_request') { unset($db['requests'][str_in(isset($in['user']) ? $in['user'] : '')]); done($db); }
if ($action === 'invite_create') {
  $r = (isset($in['role']) && $in['role'] === 'management') ? 'management' : 'angajat';
  $days = max(1, min(60, intval(isset($in['days']) ? $in['days'] : 14)));
  $tok = bin2hex(random_bytes(16));
  $db['invites'][$tok] = array('role' => $r, 'exp' => time() + $days * 86400, 'by' => $me['user'], 'uses' => 0, 'at' => time());
  done($db, array('token' => $tok));
}
if ($action === 'invite_revoke') { unset($db['invites'][str_in(isset($in['token']) ? $in['token'] : '')]); done($db); }
if ($action === 'approve_join') {
  $id = str_in(isset($in['id']) ? $in['id'] : ''); if (!isset($db['pending'][$id])) { db_close(); fail(404, 'missing'); }
  $p = $db['pending'][$id]; $r = (isset($in['role']) && $in['role'] === 'management') ? 'management' : ((isset($in['role']) && $in['role'] === 'angajat') ? 'angajat' : $p['role']);
  $ul = fopen($dir . '/.users.lock', 'c'); flock($ul, LOCK_EX);
  $users = jload($usersF);
  if (!is_file($usersF) || !is_array($users) || count($users) === 0) { flock($ul, LOCK_UN); fclose($ul); db_close(); fail(500, 'users_unreadable'); }   // nu scriem niciodată peste o listă goală
  foreach ($users as $x) { if (isset($x['user']) && $x['user'] === $p['user']) { flock($ul, LOCK_UN); fclose($ul); unset($db['pending'][$id]); $db = db_save($db); db_close(); fail(409, 'user_exists'); } }
  $users[] = array('user' => $p['user'], 'name' => $p['name'], 'role' => 'staff', 'hash' => $p['hash'], 'created' => time(), 'via' => 'ievent');
  jsave($usersF, $users); flock($ul, LOCK_UN); fclose($ul);
  $db['members'][$p['user']] = array('role' => $r, 'by' => $me['user'], 'at' => time());
  unset($db['pending'][$id]);
  add_notif($db, $p['name'] . ' are cont și acces la iEvent ca ' . ($r === 'management' ? 'Management' : 'Angajat'), $me['user'], $me['name'], null);
  done($db);
}
if ($action === 'reject_join') { unset($db['pending'][str_in(isset($in['id']) ? $in['id'] : '')]); done($db); }
if ($action === 'export') { db_close(); $o = array('format' => 'ievent-export', 'at' => time()); foreach ($COLLS as $c) $o[$c] = (object)$db[$c]; out($o); }

db_close();
fail(400, 'unknown_action');
