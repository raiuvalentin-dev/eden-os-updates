<?php
// EDEN OS — sync backend (beta). Acces DOAR cu sesiune valida (login prin auth.php).
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
$dir = __DIR__ . '/data';
$file = $dir . '/state.json';
$sessF = $dir . '/sessions.json';
if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
$ht = $dir . '/.htaccess';
if (!is_file($ht)) { @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n"); }
// validare sesiune
function eden_session(){ global $sessF; $tok = isset($_SERVER['HTTP_X_EDEN_SESSION']) ? $_SERVER['HTTP_X_EDEN_SESSION'] : (isset($_GET['s'])?$_GET['s']:''); if(!$tok) return null; if(!is_file($sessF)) return null; $s=json_decode(file_get_contents($sessF),true); if(!is_array($s)||!isset($s[$tok])) return null; if($s[$tok]['exp'] < time()) return null; return $s[$tok]; }
$me = eden_session();
if (!$me) { http_response_code(401); echo json_encode(array('error'=>'no_session')); exit; }
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'GET') {
  if (is_file($file)) { $raw = file_get_contents($file);
    if (is_file($dir . '/autorizari/ev/.migrat') && strpos($raw, '"autorizari"') !== false) { $d = json_decode($raw); if (is_object($d) && isset($d->state->autorizari->events)) { unset($d->state->autorizari->events, $d->state->autorizari->cur); $j = json_encode($d); if ($j !== false) $raw = $j; } }
    echo $raw; }
  else { echo json_encode(array('ts' => 0, 'state' => new stdClass())); }
  exit;
}
if ($method === 'POST') {
  $raw = file_get_contents('php://input');
  if (strlen($raw) > 8000000) { http_response_code(413); echo json_encode(array('error'=>'too_large')); exit; }
  $in = json_decode($raw, true);
  if (!is_array($in) || !array_key_exists('state', $in)) { http_response_code(400); echo json_encode(array('error'=>'bad_request')); exit; }
  if (is_file($dir . '/autorizari/ev/.migrat') && isset($in['state']['autorizari']) && is_array($in['state']['autorizari'])) { unset($in['state']['autorizari']['events'], $in['state']['autorizari']['cur']); }   // evenimentele stau in autorizari.php, pe companii
  $ts = isset($in['ts']) ? intval($in['ts']) : 0;
  $cur = is_file($file) ? json_decode(file_get_contents($file), true) : array('ts'=>0);
  $curTs = (is_array($cur) && isset($cur['ts'])) ? intval($cur['ts']) : 0;
  if ($ts >= $curTs) {
    $out = json_encode(array('ts'=>$ts,'state'=>$in['state'],'by'=>$me['user']));
    $tmp = $file . '.tmp'; file_put_contents($tmp, $out, LOCK_EX); rename($tmp, $file);
    echo json_encode(array('ok'=>true,'ts'=>$ts));
  } else {
    echo json_encode(array('ok'=>false,'conflict'=>true,'ts'=>$curTs));
  }
  exit;
}
http_response_code(405); echo json_encode(array('error'=>'method_not_allowed'));
