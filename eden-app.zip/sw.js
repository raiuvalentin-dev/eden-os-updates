/* EDEN OS — service worker v3 (offline + canal direct de update) */
var CACHE='eden-os-v37';
var SHELL=['./','./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./icons/apple-touch-icon.png'];
self.addEventListener('install',function(e){e.waitUntil(caches.open(CACHE).then(function(c){return c.addAll(SHELL);}).then(function(){return self.skipWaiting();}));});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k!==CACHE;}).map(function(k){return caches.delete(k);}));}).then(function(){return self.clients.claim();}));});
self.addEventListener('fetch',function(e){
  if(e.request.method!=='GET')return;
  // backend dinamic (auth/OAuth/state/API): mereu din retea, niciodata din cache
  if(/\.php(\?|#|$)|\/api\//.test(e.request.url)){ e.respondWith(fetch(e.request)); return; }   // orice .php: raspunsul serverului nu se pastreaza si nu se inlocuieste niciodata
  var netFirst=/app\.html|admin\.html|verificator\.html|ievent\.html|autorizari\.html|magazie\.html|semnare\.html|version\.json|system\.json/.test(e.request.url);
  if(netFirst){
    // aplicatia + versiunea: retea intai (mereu ultima cand esti online), cache pt offline
    e.respondWith(fetch(e.request).then(function(r){var c=r.clone();caches.open(CACHE).then(function(ca){try{ca.put(e.request,c);}catch(x){}});return r;}).catch(function(){return caches.match(e.request).then(function(r){return r||caches.match('./app.html');});}));
  } else {
    // coaja + iconite: cache intai (porneste instant, offline)
    e.respondWith(caches.match(e.request).then(function(r){return r||fetch(e.request).then(function(rr){var c=rr.clone();caches.open(CACHE).then(function(ca){try{ca.put(e.request,c);}catch(x){}});return rr;}).catch(function(){return caches.match('./index.html');});}));
  }
});
