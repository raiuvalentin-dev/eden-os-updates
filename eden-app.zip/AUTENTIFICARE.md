# EDEN — Autentificare (Faza 2.5+)

Metode disponibile în ecranul de login. **Parola** merge mereu. Restul apar **doar** dacă le configurezi.

## Ce merge fără configurare
- **Parolă** (utilizator + parolă, hash-uite pe server).
- **Google Authenticator (2FA / TOTP)** — cod de 6 cifre, opțional per cont. Complet funcțional, fără chei externe.
  - După login, apasă butonul **🔒 2FA** (dreapta-jos) → scanează QR-ul cu Google Authenticator/Authy (sau apasă „Adaugă direct în aplicație" pe telefon) → introdu codul → 2FA activ.
  - La următoarele login-uri, după parolă se cere codul de 6 cifre.
  - Dezactivare: butonul 🔒 2FA → introdu un cod curent → Dezactivează.

## Ce necesită chei de la tine (opțional)
Copiază `data/auth_config.sample.json` → `data/auth_config.json` și completează. Butonul apare în login imediat ce cheile sunt puse.

### Google
1. console.cloud.google.com → APIs & Services → Credentials → **OAuth client ID (Web)**.
2. Authorized redirect URI: `<base_url>/auth.php?action=oauth_callback&provider=google`
3. Pune `client_id` + `client_secret` în config. Setează `app.base_url` (ex: `https://universulhoreca.ro/eden`).

### Facebook
1. developers.facebook.com → App → **Facebook Login**.
2. Valid OAuth Redirect URIs: `<base_url>/auth.php?action=oauth_callback&provider=facebook`
3. Pune `app_id` + `app_secret`.

### WhatsApp (OTP)
1. **Meta WhatsApp Cloud API**: obține `token` (access token permanent) + `phone_number_id`.
2. Pentru livrare oricând (nu doar în fereastra de 24h), creează un **template aprobat** cu 1 parametru în body și pune numele în `template`. Altfel se trimite mesaj text simplu.
3. Login: user introduce numărul cu prefix (ex: 40712…), primește cod pe WhatsApp, îl introduce.

## Note de securitate
- Conturile create prin Google/Facebook/WhatsApp se leagă după email/telefon. Primul cont creat devine **owner**, restul `staff`.
- `data/` este blocat din web (`.htaccess` Deny all); cheile și sesiunile nu sunt accesibile din browser.
- Pasul de creare/login al contului îl faci tu (regulă de siguranță) — eu nu introduc parole/chei.
