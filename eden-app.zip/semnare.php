<?php
// EDEN OS — semnare electronica (semnatura simpla) a fluturasilor si a statelor de plata ale zilierilor.
// Administratorul face cate un link pentru fiecare om; omul vede DOAR documentul lui, semneaza o data, iar linkul se blocheaza.
// Pe server se pastreaza doar amprenta (sha256) a codului din link, niciodata codul.
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');
header('Referrer-Policy: no-referrer');

$dir = __DIR__ . '/data';
$sd = $dir . '/semnare';
$sessF = $dir . '/sessions.json';
if (!is_dir($sd)) @mkdir($sd, 0755, true);
$ht = $dir . '/.htaccess';
if (!is_file($ht)) @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");

function out($d) { echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
function fail($code, $msg) { http_response_code($code); out(array('error' => $msg)); }
function jload($f) { if (!is_file($f)) return null; $d = json_decode(file_get_contents($f), true); return is_array($d) ? $d : null; }
function jsave($f, $d) { $t = $f . '.' . bin2hex(random_bytes(4)) . '.tmp'; file_put_contents($t, json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX); rename($t, $f); }
function txt($v, $max) { $v = is_scalar($v) ? trim((string)$v) : ''; $v = preg_replace('/[\x00-\x1F\x7F]/u', ' ', $v); return function_exists('mb_substr') ? mb_substr($v, 0, $max, 'UTF-8') : substr($v, 0, $max); }
function admin_or_die() {
  global $sessF;
  $tok = isset($_SERVER['HTTP_X_EDEN_SESSION']) ? $_SERVER['HTTP_X_EDEN_SESSION'] : '';
  if (!$tok) fail(401, 'no_session');
  $s = jload($sessF); if (!$s || !isset($s[$tok]) || $s[$tok]['exp'] < time()) fail(401, 'no_session');
  if (isset($s[$tok]['role']) && $s[$tok]['role'] === 'staff') fail(403, 'forbidden');
  return $s[$tok];
}
function tok_ok($t) { return is_string($t) && preg_match('/^[a-f0-9]{48}$/', $t); }
function rec_file($t) { global $sd; return $sd . '/' . hash('sha256', $t) . '.json'; }
function idx_file() { global $sd; return $sd . '/index.json'; }
function doc_hash($r) { return hash('sha256', json_encode(array($r['tip'], $r['titlu'], $r['firma'], $r['om'], $r['perioada'], $r['rows'], $r['total'], $r['text']), JSON_UNESCAPED_UNICODE)); }
function norm_nume($s) {
  $s = function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
  $s = strtr($s, array('ă' => 'a', 'â' => 'a', 'î' => 'i', 'ș' => 's', 'ş' => 's', 'ț' => 't', 'ţ' => 't', '-' => ' '));
  return trim(preg_replace('/\s+/', ' ', preg_replace('/[^a-z ]/', ' ', $s)));
}

$a = isset($_GET['a']) ? $_GET['a'] : '';
$raw = file_get_contents('php://input');
if (strlen($raw) > 2000000) fail(413, 'too_large');
$in = json_decode($raw, true); if (!is_array($in)) $in = array();

// ---------- administrator: face linkurile ----------
if ($a === 'creeaza') {
  $me = admin_or_die();
  $docs = isset($in['docs']) && is_array($in['docs']) ? $in['docs'] : array();
  if (!count($docs) || count($docs) > 300) fail(400, 'nr_documente');
  $idxF = idx_file(); $lk = fopen($idxF . '.lock', 'c'); flock($lk, LOCK_EX);
  $idx = jload($idxF); if (!$idx) $idx = array();
  $rez = array(); $acum = time();
  foreach ($docs as $d) {
    if (!is_array($d)) continue;
    $rows = array();
    foreach ((isset($d['rows']) && is_array($d['rows']) ? $d['rows'] : array()) as $r) {
      if (count($rows) >= 60) break;
      if (is_array($r)) $rows[] = array(txt(isset($r[0]) ? $r[0] : '', 80), txt(isset($r[1]) ? $r[1] : '', 80), !empty($r[2]) ? 1 : 0);
    }
    $zile = isset($d['zile']) ? intval($d['zile']) : 30; if ($zile < 1 || $zile > 60) $zile = 30;
    $t = bin2hex(random_bytes(24));
    $r = array(
      'v' => 1, 'id' => 'sg_' . bin2hex(random_bytes(6)), 'ref' => txt(isset($d['ref']) ? $d['ref'] : '', 80),
      'tip' => (isset($d['tip']) && $d['tip'] === 'zilier') ? 'zilier' : 'fluturas',
      'titlu' => txt(isset($d['titlu']) ? $d['titlu'] : '', 160), 'firma' => txt(isset($d['firma']) ? $d['firma'] : '', 160),
      'om' => txt(isset($d['om']) ? $d['om'] : '', 120), 'functie' => txt(isset($d['functie']) ? $d['functie'] : '', 120),
      'perioada' => txt(isset($d['perioada']) ? $d['perioada'] : '', 80), 'rows' => $rows,
      'total' => array(txt(isset($d['total'][0]) ? $d['total'][0] : '', 80), txt(isset($d['total'][1]) ? $d['total'][1] : '', 80)),
      'text' => txt(isset($d['text']) ? $d['text'] : '', 400),
      'creat' => $acum, 'de' => isset($me['user']) ? $me['user'] : '', 'expira' => $acum + $zile * 86400, 'stare' => 'trimis'
    );
    if ($r['om'] === '') continue;
    $r['h'] = doc_hash($r);
    jsave(rec_file($t), $r);
    $idx[$r['id']] = hash('sha256', $t);
    $rez[] = array('ref' => $r['ref'], 'id' => $r['id'], 't' => $t, 'expira' => $r['expira']);
  }
  jsave($idxF, $idx); flock($lk, LOCK_UN); fclose($lk);
  out(array('ok' => true, 'linkuri' => $rez));
}

// ---------- administrator: starea linkurilor (și documentul semnat, la cerere) ----------
if ($a === 'stare' || $a === 'anuleaza') {
  admin_or_die();
  $ids = isset($in['ids']) && is_array($in['ids']) ? array_slice($in['ids'], 0, 600) : array();
  $idx = jload(idx_file()); if (!$idx) $idx = array();
  $rez = array();
  foreach ($ids as $id) {
    if (!is_string($id) || !isset($idx[$id])) { $rez[] = array('id' => $id, 'stare' => 'necunoscut'); continue; }
    $f = $sd . '/' . $idx[$id] . '.json'; $r = jload($f);
    if (!$r) { $rez[] = array('id' => $id, 'stare' => 'necunoscut'); continue; }
    if ($a === 'anuleaza' && $r['stare'] === 'trimis') { $r['stare'] = 'anulat'; $r['anulat'] = time(); jsave($f, $r); }
    $st = $r['stare'] === 'trimis' && $r['expira'] < time() ? 'expirat' : $r['stare'];
    $o = array('id' => $id, 'ref' => $r['ref'], 'stare' => $st, 'creat' => $r['creat'], 'expira' => $r['expira'], 'vazut' => isset($r['vazut']) ? $r['vazut'] : null);
    if ($r['stare'] === 'semnat') {
      $o['semnat'] = $r['semnat']; $o['nume'] = $r['nume']; $o['ok_hash'] = ($r['h'] === doc_hash($r));
      if (!empty($in['complet'])) { foreach (array('tip', 'titlu', 'firma', 'om', 'functie', 'perioada', 'rows', 'total', 'text', 'h', 'semnatura', 'ip', 'ua') as $k) $o[$k] = isset($r[$k]) ? $r[$k] : null; }
    }
    $rez[] = $o;
  }
  out(array('ok' => true, 'stari' => $rez));
}

// ---------- angajatul: își vede documentul (doar cât timp nu e semnat) ----------
if ($a === 'vezi' || $a === 'semneaza') {
  $t = isset($in['t']) ? $in['t'] : '';
  if (!tok_ok($t)) fail(404, 'link_invalid');
  $f = rec_file($t);
  if (!is_file($f)) fail(404, 'link_invalid');
  $lk = fopen($f . '.lock', 'c'); flock($lk, LOCK_EX);
  $r = jload($f);
  if (!$r) fail(404, 'link_invalid');
  if ($r['stare'] === 'semnat') out(array('stare' => 'semnat', 'semnat' => $r['semnat']));
  if ($r['stare'] === 'anulat') out(array('stare' => 'anulat'));
  if ($r['expira'] < time()) out(array('stare' => 'expirat'));
  if ($a === 'vezi') {
    if (empty($r['vazut'])) { $r['vazut'] = time(); jsave($f, $r); }
    out(array('stare' => 'trimis', 'doc' => array('tip' => $r['tip'], 'titlu' => $r['titlu'], 'firma' => $r['firma'], 'om' => $r['om'], 'functie' => $r['functie'], 'perioada' => $r['perioada'], 'rows' => $r['rows'], 'total' => $r['total'], 'text' => $r['text'], 'h' => $r['h'])));
  }
  // semneaza
  $sig = isset($in['semnatura']) ? $in['semnatura'] : '';
  if (!is_string($sig) || strpos($sig, 'data:image/png;base64,') !== 0 || strlen($sig) > 400000) fail(400, 'semnatura_lipsa');
  $bin = base64_decode(substr($sig, 22), true);
  if ($bin === false || substr($bin, 0, 8) !== "\x89PNG\r\n\x1a\n" || strlen($bin) < 600) fail(400, 'semnatura_lipsa');
  if (empty($in['acord'])) fail(400, 'acord_lipsa');
  $nume = txt(isset($in['nume']) ? $in['nume'] : '', 120);
  $nn = norm_nume($nume); $no = norm_nume($r['om']);
  if ($nn === '' || count(array_intersect(explode(' ', $nn), explode(' ', $no))) < min(2, count(explode(' ', $no)))) fail(400, 'nume_diferit');
  if (isset($in['h']) && $in['h'] !== $r['h']) fail(409, 'document_schimbat');
  $r['stare'] = 'semnat'; $r['semnat'] = date('c'); $r['nume'] = $nume; $r['semnatura'] = $sig;
  $r['ip'] = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
  $r['ua'] = txt(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '', 300);
  jsave($f, $r);
  flock($lk, LOCK_UN); fclose($lk);
  out(array('ok' => true, 'stare' => 'semnat', 'semnat' => $r['semnat']));
}

fail(400, 'unknown_action');
