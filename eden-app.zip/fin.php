<?php
/* Universul HoReCa — Financiar Eveniment: chat + tickete (per eveniment).
   POST {kind:"chat"|"ticket", ev, nume, mesaj, tip?, prioritate?} -> salveaza in data/fin_<kind>.json
   GET  ?key=UHFIN2026&ev=<id> -> {ok, chat:[...], tickets:[...]}  (filtrat pe eveniment)
   GET  fara key -> doar numarul de mesaje. */
header('Content-Type: application/json; charset=utf-8');
$dir=__DIR__.'/data'; if(!is_dir($dir)) @mkdir($dir,0775,true);
$fc=$dir.'/fin_chat.json'; $ft=$dir.'/fin_tickets.json';
$KEY='UHFIN2026';
function ld($f){ if(!is_file($f))return array(); $j=json_decode(file_get_contents($f),true); return is_array($j)?$j:array(); }
$m=$_SERVER['REQUEST_METHOD'];

if($m==='POST'){
  $raw=file_get_contents('php://input');
  if(strlen($raw)>20000){http_response_code(413);echo json_encode(array('error'=>'too_large'));exit;}
  $in=json_decode($raw,true);
  if(!is_array($in)||!isset($in['mesaj'])||trim($in['mesaj'])===''){http_response_code(400);echo json_encode(array('error'=>'bad'));exit;}
  $kind=isset($in['kind'])&&$in['kind']==='ticket'?'ticket':'chat';
  $f=$kind==='ticket'?$ft:$fc; $list=ld($f);
  $ipHash=hash('sha256',(isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'').'uh-fin');
  $now=time(); $recent=0; foreach($list as $x){ if(isset($x['ip'])&&$x['ip']===$ipHash&&($now-(int)$x['ts'])<600)$recent++; }
  if($recent>=40){http_response_code(429);echo json_encode(array('error'=>'rate'));exit;}
  $e=array(
    'id'=>uniqid($kind.'_'),
    'ev'=>mb_substr(trim(isset($in['ev'])?$in['ev']:''),0,80),
    'nume'=>mb_substr(trim(isset($in['nume'])?$in['nume']:'Anonim'),0,80),
    'mesaj'=>mb_substr(trim($in['mesaj']),0,4000),
    'ts'=>$now,'ip'=>$ipHash
  );
  if($kind==='ticket'){
    $e['tip']=mb_substr(trim(isset($in['tip'])?$in['tip']:'Alertă financiară'),0,60);
    $e['prioritate']=mb_substr(trim(isset($in['prioritate'])?$in['prioritate']:'Normală'),0,20);
    $e['stare']='deschis';
  }
  $list[]=$e; if(count($list)>2000)$list=array_slice($list,-2000);
  file_put_contents($f,json_encode($list,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),LOCK_EX);
  echo json_encode(array('ok'=>true,'id'=>$e['id'])); exit;
}

if($m==='GET'){
  if(isset($_GET['key'])&&$_GET['key']===$KEY){
    $ev=isset($_GET['ev'])?$_GET['ev']:'';
    function pick($list,$ev){$o=array();foreach($list as $x){if($ev&&isset($x['ev'])&&$x['ev']!==$ev)continue;unset($x['ip']);$o[]=$x;}return $o;}
    echo json_encode(array('ok'=>true,'chat'=>pick(ld($fc),$ev),'tickets'=>pick(ld($ft),$ev)),JSON_UNESCAPED_UNICODE);
  } else {
    echo json_encode(array('ok'=>true,'chat'=>count(ld($fc)),'tickets'=>count(ld($ft))));
  }
  exit;
}
http_response_code(405); echo json_encode(array('error'=>'method'));
